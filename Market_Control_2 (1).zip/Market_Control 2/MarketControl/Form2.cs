﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarketControl
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnPlayPc_Click(object sender, EventArgs e)
        {
            Form form6 = new Form6();
            form6.Show();
            this.Hide();
        }

        private void btnRules_Click(object sender, EventArgs e)
        {
            Form form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
            btnPlayPc.Visible = false;
        }


        int dial = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            switch (dial)
            {
                case 0:
                    dialogo.Text = "O jogo resume-se a ser uma dispota de dois jogadores " +
                                    "em controlar o mercado do jogo.";
                    pictureBox2.Image = MarketControl.Properties.Resources.avataaars2;
                    dial++;
                    break;
               case 1:
                    dialogo.Text = "E ao longo do jogo vais poder comprar casas dos " +
                                     "estadios de futebol.";
                    pictureBox2.Image = MarketControl.Properties.Resources.avataaars3;
                    dial++;
                    break;
                case 2:
                    dialogo.Text = "E claro também há cartas da sorte e cartas da comunidade" +
                                    " em que pode ou não ter vantagens.";
                    pictureBox2.Image = MarketControl.Properties.Resources.avataaars4;
                    dial++;
                    break;
                case 3:
                    dialogo.Text = "Mas podes esclarecer melhor as tuas duvidas nas regras" +
                                    " do jogo no botão que tem um icon de um \"?\".";
                    pictureBox2.Image = MarketControl.Properties.Resources.avataaars__1_;
                    dial++;
                    break;
                case 4:
                    dialogo.Text = "Então agora já estas pronto para jogar o " +
                        "Market Control." +
                        "Agora desfrute do jogo";
                    dial++;
                    break;
                case 5:
                    pictureBox2.Visible = false;
                    dialogo.Visible = false;
                    dial = 0;
                    btnPlayPc.Visible = true;
                    button2.Visible = false;
                    break;
            }
            

            
        }
    }
}
