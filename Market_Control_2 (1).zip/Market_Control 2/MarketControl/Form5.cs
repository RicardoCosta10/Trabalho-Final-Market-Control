﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarketControl
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            pbcl.Visible = false;
            pbcac.Visible = false;
            pbcae.Visible = false;
            pbcap.Visible = false;
            pbca.Visible = false;
            pbcm.Visible = false;
            pbcv.Visible = false;
            pbcve.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Program.cor1[0] == 1)
            { 
                pbcap.Visible = true;
                if (Program.compra1 == 1)
                {
                    Tap.Text = "Milão";
                    Nomeap.Text = "Inter de Milão";
                    Casaap.Text = "Valor a pagar                50ka";
                }
                if (Program.compra1 == 2)
                { 
                    Tap.Text = "Londres";
                    Nomeap.Text = "Chelsea";
                    Casaap.Text = "Valor a pagar                50ka";
                }
            }
            if (Program.cor1[1] == 2)
            {
                    pbcac.Visible = true;
                if (Program.compra1 == 3)
                { 
                    Tac.Text = "Roma";
                    Nomeac.Text = "Lazio";
                    Casaac.Text = "Valor a pagar                100ka";
                }
                if (Program.compra1 == 4)
                {
                    Tac.Text = "Manchester";
                    Nomeac.Text = "Man. City";
                    Casaac.Text = "Valor a pagar                100ka";
                }
                if (Program.compra1 == 5)
                { 
                    Tac.Text = "Madrid";
                    Nomeac.Text = "Atletico de Madrid";
                    Casaac.Text = "Valor a pagar                100ka";
                }
            }
            if (Program.cor1[2] == 3)
            {
                pbcm.Visible = true;
                if (Program.compra1 == 6)
                { 
                    Tm.Text = "Barcelona";
                    Nomem.Text = "Barcelona";
                    Casam.Text = "Valor a pagar                150ka";
                }
                if (Program.compra1 == 7)
                { 
                    Tm.Text = "Rio de Janeiro";
                    Nomem.Text = "Flamengo";
                    Casam.Text = "Valor a pagar                150ka";
                }
                if (Program.compra1 == 8)
                {
                    Tm.Text = "Madrid";
                    Nomem.Text = "Real Madrid";
                    Casam.Text = "Valor a pagar                150ka";
                }
            }
            if (Program.cor1[3] == 4)
            {
                pbcl.Visible = true;
                if (Program.compra1 == 9)
                { 
                    Tl.Text = "Liverpool";
                    Nomel.Text = "Liverpool";
                    Casal.Text = "Valor a pagar                200ka";
                }
                if (Program.compra1 == 10)
                {
                    Tl.Text = "Porto";
                    Nomel.Text = "Porto";
                    Casal.Text = "Valor a pagar                200ka";
                }
                if (Program.compra1 == 11)
                { 
                    Tl.Text = "Turim";
                    Nomel.Text = "Juventus";
                    Casal.Text = "Valor a pagar                200ka";
                }
            }
            if (Program.cor1[4] == 5)
            {
                pbcv.Visible = true;
                if (Program.compra1 == 12)
                { 
                    Tv.Text = "Lisboa";
                    Nomev.Text = "Benfica";
                    Casav.Text = "Valor a pagar                250ka";
                }
                if (Program.compra1 == 13)
                { 
                    Tv.Text = "Manchester";
                    Nomev.Text = "Man. United";
                    Casav.Text = "Valor a pagar                250ka";
                }
                if (Program.compra1 == 14)
                {
                    Tv.Text = "Munique";
                    Nomev.Text = "Bayern München";
                    Casav.Text = "Valor a pagar                250ka";
                }
            }
            if (Program.cor1[5] == 6)
            {
                pbca.Visible = true;
                if (Program.compra1 == 15)
                { 
                    Ta.Text = "Dortmund";
                    Nomea.Text = "Dortmund";
                    Casaa.Text = "Valor a pagar                300ka";
                }
                if (Program.compra1 == 16)
                { 
                    Ta.Text = "Hertfordshire";
                    Nomea.Text = "Watford";
                    Casaa.Text = "Valor a pagar                300ka";
                }
                if (Program.compra1 == 17)
                {
                    Ta.Text = "Paris";
                    Nomea.Text = "PSG";
                    Casaa.Text = "Valor a pagar                300ka";
                }
            }
            if (Program.cor1[6] == 7)
            {
                pbcve.Visible = true;
                if (Program.compra1 == 18)
                { 
                    Tve.Text = "Wolfsburg";
                    Nomeve.Text = "Wolfsburg";
                    Casave.Text = "Valor a pagar                350ka";
                }
                if (Program.compra1 == 19)
                {
                    Tve.Text = "Glasgow";
                    Nomeve.Text = "Celtic";
                    Casave.Text = "Valor a pagar                350ka";
                }
                if (Program.compra1 == 20)
                { 
                    Tve.Text = "Sevilha";
                    Nomeve.Text = "Real Betis";
                    Casave.Text = "Valor a pagar                350ka";
                }
            }
            if (Program.cor1[7] == 8)
            {
                pbcae.Visible = true;
                if (Program.compra1 == 21)
                { 
                    Tae.Text = "Lisboa";
                    Nomeae.Text = "Sporting";
                    Casaae.Text = "Valor a pagar                400ka";
                }
                if (Program.compra1 == 22)
                {
                    pbcae.Visible = true;
                    Tae.Text = "Istambul";
                    Nomeae.Text = "Beşiktaş";
                    Casaae.Text = "Valor a pagar                400ka";
                }
            }
        }
    }
}
