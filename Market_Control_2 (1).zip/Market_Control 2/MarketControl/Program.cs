﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarketControl
{
    internal static class Program
    {
        public static int winloss = 0;
        public static int[] imagem = new int[] { 0, 0, 0, 0 };
        public static int money = 1500;
        public static int money2 = 1500;
        public static int pos=0;
        public static int pos2 = 0;
        public static int[] cor = new int[] {0,0,0,0,0,0,0,0};//destinguir a cor
        public static int[] cor1 = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
        public static int compra = 0;//destinguir as casas de compra
        public static int compra1 = 0;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form2());
        }
    }
}
