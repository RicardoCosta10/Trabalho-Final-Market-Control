﻿namespace MarketControl
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRules = new System.Windows.Forms.Button();
            this.btnPlayPc = new System.Windows.Forms.Button();
            this.dialogo = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRules
            // 
            this.btnRules.BackColor = System.Drawing.Color.Snow;
            this.btnRules.Font = new System.Drawing.Font("MS Reference Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRules.Location = new System.Drawing.Point(1073, 28);
            this.btnRules.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRules.Name = "btnRules";
            this.btnRules.Size = new System.Drawing.Size(56, 50);
            this.btnRules.TabIndex = 3;
            this.btnRules.TabStop = false;
            this.btnRules.Text = "?";
            this.btnRules.UseVisualStyleBackColor = false;
            this.btnRules.Click += new System.EventHandler(this.btnRules_Click);
            // 
            // btnPlayPc
            // 
            this.btnPlayPc.BackColor = System.Drawing.Color.Yellow;
            this.btnPlayPc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPlayPc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayPc.Location = new System.Drawing.Point(488, 423);
            this.btnPlayPc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPlayPc.Name = "btnPlayPc";
            this.btnPlayPc.Size = new System.Drawing.Size(160, 50);
            this.btnPlayPc.TabIndex = 1;
            this.btnPlayPc.TabStop = false;
            this.btnPlayPc.Text = "Jogar";
            this.btnPlayPc.UseVisualStyleBackColor = false;
            this.btnPlayPc.Click += new System.EventHandler(this.btnPlayPc_Click);
            // 
            // dialogo
            // 
            this.dialogo.BackColor = System.Drawing.Color.DarkTurquoise;
            this.dialogo.Font = new System.Drawing.Font("Palatino Linotype", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dialogo.Location = new System.Drawing.Point(325, 526);
            this.dialogo.Name = "dialogo";
            this.dialogo.Size = new System.Drawing.Size(476, 151);
            this.dialogo.TabIndex = 5;
            this.dialogo.Text = "Olá, muito bem vindo ao meu jogo!\r\nEu sou o Damon Thales, o Proprietario deste jo" +
    "go a qual dei o nome \"Market Control\".\r\n";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(698, 638);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 39);
            this.button2.TabIndex = 7;
            this.button2.Text = "Avançar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::MarketControl.Properties.Resources.avataaars__1_;
            this.pictureBox2.Location = new System.Drawing.Point(21, 359);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(314, 318);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MarketControl.Properties.Resources.logo1;
            this.pictureBox1.Location = new System.Drawing.Point(233, 28);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 256);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tomato;
            this.ClientSize = new System.Drawing.Size(1152, 678);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dialogo);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnRules);
            this.Controls.Add(this.btnPlayPc);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.Text = "Market Control";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnPlayPc;
        private System.Windows.Forms.Button btnRules;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label dialogo;
        private System.Windows.Forms.Button button2;
    }
}