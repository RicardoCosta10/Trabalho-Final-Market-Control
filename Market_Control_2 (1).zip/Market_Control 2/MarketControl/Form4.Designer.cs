﻿namespace MarketControl
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Casa2v = new System.Windows.Forms.Label();
            this.Casav = new System.Windows.Forms.Label();
            this.Nomev = new System.Windows.Forms.Label();
            this.Tv = new System.Windows.Forms.Label();
            this.Casa2ve = new System.Windows.Forms.Label();
            this.Casave = new System.Windows.Forms.Label();
            this.Nomeve = new System.Windows.Forms.Label();
            this.Tve = new System.Windows.Forms.Label();
            this.Casa2m = new System.Windows.Forms.Label();
            this.Casam = new System.Windows.Forms.Label();
            this.Nomem = new System.Windows.Forms.Label();
            this.Tm = new System.Windows.Forms.Label();
            this.Casa2l = new System.Windows.Forms.Label();
            this.Casal = new System.Windows.Forms.Label();
            this.Nomel = new System.Windows.Forms.Label();
            this.Tl = new System.Windows.Forms.Label();
            this.Casa2ap = new System.Windows.Forms.Label();
            this.Casaap = new System.Windows.Forms.Label();
            this.Nomeap = new System.Windows.Forms.Label();
            this.Tap = new System.Windows.Forms.Label();
            this.Casa2ae = new System.Windows.Forms.Label();
            this.Casaae = new System.Windows.Forms.Label();
            this.Nomeae = new System.Windows.Forms.Label();
            this.Tae = new System.Windows.Forms.Label();
            this.Casa2a = new System.Windows.Forms.Label();
            this.Casaa = new System.Windows.Forms.Label();
            this.Nomea = new System.Windows.Forms.Label();
            this.Ta = new System.Windows.Forms.Label();
            this.Casa2ac = new System.Windows.Forms.Label();
            this.Casaac = new System.Windows.Forms.Label();
            this.Nomeac = new System.Windows.Forms.Label();
            this.Tac = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.pbcap = new System.Windows.Forms.PictureBox();
            this.pbcv = new System.Windows.Forms.PictureBox();
            this.pbcae = new System.Windows.Forms.PictureBox();
            this.pbcac = new System.Windows.Forms.PictureBox();
            this.pbca = new System.Windows.Forms.PictureBox();
            this.pbcl = new System.Windows.Forms.PictureBox();
            this.pbcm = new System.Windows.Forms.PictureBox();
            this.pbcve = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbcap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcae)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcac)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcve)).BeginInit();
            this.SuspendLayout();
            // 
            // Casa2v
            // 
            this.Casa2v.AutoSize = true;
            this.Casa2v.Location = new System.Drawing.Point(964, 561);
            this.Casa2v.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2v.Name = "Casa2v";
            this.Casa2v.Size = new System.Drawing.Size(0, 16);
            this.Casa2v.TabIndex = 107;
            // 
            // Casav
            // 
            this.Casav.AutoSize = true;
            this.Casav.BackColor = System.Drawing.Color.Transparent;
            this.Casav.Location = new System.Drawing.Point(964, 506);
            this.Casav.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casav.Name = "Casav";
            this.Casav.Size = new System.Drawing.Size(0, 16);
            this.Casav.TabIndex = 106;
            // 
            // Nomev
            // 
            this.Nomev.AutoSize = true;
            this.Nomev.Location = new System.Drawing.Point(1053, 457);
            this.Nomev.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomev.Name = "Nomev";
            this.Nomev.Size = new System.Drawing.Size(0, 16);
            this.Nomev.TabIndex = 105;
            // 
            // Tv
            // 
            this.Tv.AutoSize = true;
            this.Tv.BackColor = System.Drawing.Color.Transparent;
            this.Tv.Location = new System.Drawing.Point(1053, 430);
            this.Tv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tv.Name = "Tv";
            this.Tv.Size = new System.Drawing.Size(0, 16);
            this.Tv.TabIndex = 104;
            // 
            // Casa2ve
            // 
            this.Casa2ve.AutoSize = true;
            this.Casa2ve.Location = new System.Drawing.Point(659, 561);
            this.Casa2ve.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2ve.Name = "Casa2ve";
            this.Casa2ve.Size = new System.Drawing.Size(0, 16);
            this.Casa2ve.TabIndex = 103;
            // 
            // Casave
            // 
            this.Casave.AutoSize = true;
            this.Casave.BackColor = System.Drawing.Color.Transparent;
            this.Casave.Location = new System.Drawing.Point(659, 506);
            this.Casave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casave.Name = "Casave";
            this.Casave.Size = new System.Drawing.Size(0, 16);
            this.Casave.TabIndex = 102;
            // 
            // Nomeve
            // 
            this.Nomeve.AutoSize = true;
            this.Nomeve.Location = new System.Drawing.Point(748, 457);
            this.Nomeve.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomeve.Name = "Nomeve";
            this.Nomeve.Size = new System.Drawing.Size(0, 16);
            this.Nomeve.TabIndex = 101;
            // 
            // Tve
            // 
            this.Tve.AutoSize = true;
            this.Tve.BackColor = System.Drawing.Color.Transparent;
            this.Tve.Location = new System.Drawing.Point(748, 430);
            this.Tve.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tve.Name = "Tve";
            this.Tve.Size = new System.Drawing.Size(0, 16);
            this.Tve.TabIndex = 100;
            // 
            // Casa2m
            // 
            this.Casa2m.AutoSize = true;
            this.Casa2m.Location = new System.Drawing.Point(356, 561);
            this.Casa2m.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2m.Name = "Casa2m";
            this.Casa2m.Size = new System.Drawing.Size(0, 16);
            this.Casa2m.TabIndex = 99;
            // 
            // Casam
            // 
            this.Casam.AutoSize = true;
            this.Casam.BackColor = System.Drawing.Color.Transparent;
            this.Casam.Location = new System.Drawing.Point(356, 506);
            this.Casam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casam.Name = "Casam";
            this.Casam.Size = new System.Drawing.Size(0, 16);
            this.Casam.TabIndex = 98;
            // 
            // Nomem
            // 
            this.Nomem.AutoSize = true;
            this.Nomem.Location = new System.Drawing.Point(445, 457);
            this.Nomem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomem.Name = "Nomem";
            this.Nomem.Size = new System.Drawing.Size(0, 16);
            this.Nomem.TabIndex = 97;
            // 
            // Tm
            // 
            this.Tm.AutoSize = true;
            this.Tm.BackColor = System.Drawing.Color.Transparent;
            this.Tm.Location = new System.Drawing.Point(445, 430);
            this.Tm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tm.Name = "Tm";
            this.Tm.Size = new System.Drawing.Size(0, 16);
            this.Tm.TabIndex = 96;
            // 
            // Casa2l
            // 
            this.Casa2l.AutoSize = true;
            this.Casa2l.Location = new System.Drawing.Point(56, 561);
            this.Casa2l.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2l.Name = "Casa2l";
            this.Casa2l.Size = new System.Drawing.Size(0, 16);
            this.Casa2l.TabIndex = 95;
            // 
            // Casal
            // 
            this.Casal.AutoSize = true;
            this.Casal.BackColor = System.Drawing.Color.Transparent;
            this.Casal.Location = new System.Drawing.Point(56, 506);
            this.Casal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casal.Name = "Casal";
            this.Casal.Size = new System.Drawing.Size(0, 16);
            this.Casal.TabIndex = 94;
            // 
            // Nomel
            // 
            this.Nomel.AutoSize = true;
            this.Nomel.Location = new System.Drawing.Point(145, 457);
            this.Nomel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomel.Name = "Nomel";
            this.Nomel.Size = new System.Drawing.Size(0, 16);
            this.Nomel.TabIndex = 93;
            // 
            // Tl
            // 
            this.Tl.AutoSize = true;
            this.Tl.BackColor = System.Drawing.Color.Transparent;
            this.Tl.Location = new System.Drawing.Point(145, 430);
            this.Tl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tl.Name = "Tl";
            this.Tl.Size = new System.Drawing.Size(0, 16);
            this.Tl.TabIndex = 92;
            // 
            // Casa2ap
            // 
            this.Casa2ap.AutoSize = true;
            this.Casa2ap.Location = new System.Drawing.Point(972, 210);
            this.Casa2ap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2ap.Name = "Casa2ap";
            this.Casa2ap.Size = new System.Drawing.Size(0, 16);
            this.Casa2ap.TabIndex = 91;
            // 
            // Casaap
            // 
            this.Casaap.AutoSize = true;
            this.Casaap.BackColor = System.Drawing.Color.Transparent;
            this.Casaap.Location = new System.Drawing.Point(972, 155);
            this.Casaap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casaap.Name = "Casaap";
            this.Casaap.Size = new System.Drawing.Size(0, 16);
            this.Casaap.TabIndex = 90;
            // 
            // Nomeap
            // 
            this.Nomeap.AutoSize = true;
            this.Nomeap.Location = new System.Drawing.Point(1072, 106);
            this.Nomeap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomeap.Name = "Nomeap";
            this.Nomeap.Size = new System.Drawing.Size(0, 16);
            this.Nomeap.TabIndex = 89;
            // 
            // Tap
            // 
            this.Tap.AutoSize = true;
            this.Tap.BackColor = System.Drawing.Color.Transparent;
            this.Tap.Location = new System.Drawing.Point(1072, 79);
            this.Tap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tap.Name = "Tap";
            this.Tap.Size = new System.Drawing.Size(0, 16);
            this.Tap.TabIndex = 88;
            // 
            // Casa2ae
            // 
            this.Casa2ae.AutoSize = true;
            this.Casa2ae.Location = new System.Drawing.Point(669, 210);
            this.Casa2ae.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2ae.Name = "Casa2ae";
            this.Casa2ae.Size = new System.Drawing.Size(0, 16);
            this.Casa2ae.TabIndex = 87;
            // 
            // Casaae
            // 
            this.Casaae.AutoSize = true;
            this.Casaae.BackColor = System.Drawing.Color.Transparent;
            this.Casaae.Location = new System.Drawing.Point(669, 155);
            this.Casaae.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casaae.Name = "Casaae";
            this.Casaae.Size = new System.Drawing.Size(0, 16);
            this.Casaae.TabIndex = 86;
            // 
            // Nomeae
            // 
            this.Nomeae.AutoSize = true;
            this.Nomeae.Location = new System.Drawing.Point(760, 106);
            this.Nomeae.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomeae.Name = "Nomeae";
            this.Nomeae.Size = new System.Drawing.Size(0, 16);
            this.Nomeae.TabIndex = 85;
            // 
            // Tae
            // 
            this.Tae.AutoSize = true;
            this.Tae.BackColor = System.Drawing.Color.Transparent;
            this.Tae.Location = new System.Drawing.Point(760, 79);
            this.Tae.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tae.Name = "Tae";
            this.Tae.Size = new System.Drawing.Size(0, 16);
            this.Tae.TabIndex = 84;
            // 
            // Casa2a
            // 
            this.Casa2a.AutoSize = true;
            this.Casa2a.Location = new System.Drawing.Point(367, 210);
            this.Casa2a.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2a.Name = "Casa2a";
            this.Casa2a.Size = new System.Drawing.Size(0, 16);
            this.Casa2a.TabIndex = 83;
            // 
            // Casaa
            // 
            this.Casaa.AutoSize = true;
            this.Casaa.BackColor = System.Drawing.Color.Transparent;
            this.Casaa.Location = new System.Drawing.Point(367, 155);
            this.Casaa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casaa.Name = "Casaa";
            this.Casaa.Size = new System.Drawing.Size(0, 16);
            this.Casaa.TabIndex = 82;
            // 
            // Nomea
            // 
            this.Nomea.AutoSize = true;
            this.Nomea.Location = new System.Drawing.Point(477, 106);
            this.Nomea.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomea.Name = "Nomea";
            this.Nomea.Size = new System.Drawing.Size(0, 16);
            this.Nomea.TabIndex = 81;
            // 
            // Ta
            // 
            this.Ta.AutoSize = true;
            this.Ta.BackColor = System.Drawing.Color.Transparent;
            this.Ta.Location = new System.Drawing.Point(477, 79);
            this.Ta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Ta.Name = "Ta";
            this.Ta.Size = new System.Drawing.Size(0, 16);
            this.Ta.TabIndex = 80;
            // 
            // Casa2ac
            // 
            this.Casa2ac.AutoSize = true;
            this.Casa2ac.Location = new System.Drawing.Point(52, 210);
            this.Casa2ac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casa2ac.Name = "Casa2ac";
            this.Casa2ac.Size = new System.Drawing.Size(0, 16);
            this.Casa2ac.TabIndex = 79;
            // 
            // Casaac
            // 
            this.Casaac.AutoSize = true;
            this.Casaac.BackColor = System.Drawing.Color.Transparent;
            this.Casaac.Location = new System.Drawing.Point(52, 155);
            this.Casaac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Casaac.Name = "Casaac";
            this.Casaac.Size = new System.Drawing.Size(0, 16);
            this.Casaac.TabIndex = 78;
            // 
            // Nomeac
            // 
            this.Nomeac.AutoSize = true;
            this.Nomeac.Location = new System.Drawing.Point(141, 106);
            this.Nomeac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Nomeac.Name = "Nomeac";
            this.Nomeac.Size = new System.Drawing.Size(0, 16);
            this.Nomeac.TabIndex = 77;
            // 
            // Tac
            // 
            this.Tac.AutoSize = true;
            this.Tac.BackColor = System.Drawing.Color.Transparent;
            this.Tac.Location = new System.Drawing.Point(141, 79);
            this.Tac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tac.Name = "Tac";
            this.Tac.Size = new System.Drawing.Size(0, 16);
            this.Tac.TabIndex = 76;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(16, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 39);
            this.button1.TabIndex = 67;
            this.button1.Text = "Atualizar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // pbcap
            // 
            this.pbcap.BackgroundImage = global::MarketControl.Properties.Resources.c_azul_preto;
            this.pbcap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcap.Location = new System.Drawing.Point(944, 66);
            this.pbcap.Margin = new System.Windows.Forms.Padding(4);
            this.pbcap.Name = "pbcap";
            this.pbcap.Size = new System.Drawing.Size(275, 332);
            this.pbcap.TabIndex = 75;
            this.pbcap.TabStop = false;
            // 
            // pbcv
            // 
            this.pbcv.BackgroundImage = global::MarketControl.Properties.Resources.c_vermelha;
            this.pbcv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcv.Location = new System.Drawing.Point(944, 417);
            this.pbcv.Margin = new System.Windows.Forms.Padding(4);
            this.pbcv.Name = "pbcv";
            this.pbcv.Size = new System.Drawing.Size(275, 331);
            this.pbcv.TabIndex = 74;
            this.pbcv.TabStop = false;
            // 
            // pbcae
            // 
            this.pbcae.BackgroundImage = global::MarketControl.Properties.Resources.ccinzenta;
            this.pbcae.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcae.Location = new System.Drawing.Point(641, 68);
            this.pbcae.Margin = new System.Windows.Forms.Padding(4);
            this.pbcae.Name = "pbcae";
            this.pbcae.Size = new System.Drawing.Size(275, 331);
            this.pbcae.TabIndex = 73;
            this.pbcae.TabStop = false;
            // 
            // pbcac
            // 
            this.pbcac.BackgroundImage = global::MarketControl.Properties.Resources.cazulclaro;
            this.pbcac.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcac.Location = new System.Drawing.Point(32, 66);
            this.pbcac.Margin = new System.Windows.Forms.Padding(4);
            this.pbcac.Name = "pbcac";
            this.pbcac.Size = new System.Drawing.Size(275, 332);
            this.pbcac.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbcac.TabIndex = 72;
            this.pbcac.TabStop = false;
            // 
            // pbca
            // 
            this.pbca.BackgroundImage = global::MarketControl.Properties.Resources.c_amarela;
            this.pbca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbca.Location = new System.Drawing.Point(337, 66);
            this.pbca.Margin = new System.Windows.Forms.Padding(4);
            this.pbca.Name = "pbca";
            this.pbca.Size = new System.Drawing.Size(275, 332);
            this.pbca.TabIndex = 71;
            this.pbca.TabStop = false;
            // 
            // pbcl
            // 
            this.pbcl.BackgroundImage = global::MarketControl.Properties.Resources.c_laranja;
            this.pbcl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcl.Location = new System.Drawing.Point(32, 417);
            this.pbcl.Margin = new System.Windows.Forms.Padding(4);
            this.pbcl.Name = "pbcl";
            this.pbcl.Size = new System.Drawing.Size(275, 331);
            this.pbcl.TabIndex = 70;
            this.pbcl.TabStop = false;
            // 
            // pbcm
            // 
            this.pbcm.BackgroundImage = global::MarketControl.Properties.Resources.c_magenta;
            this.pbcm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcm.Location = new System.Drawing.Point(337, 417);
            this.pbcm.Margin = new System.Windows.Forms.Padding(4);
            this.pbcm.Name = "pbcm";
            this.pbcm.Size = new System.Drawing.Size(275, 331);
            this.pbcm.TabIndex = 69;
            this.pbcm.TabStop = false;
            // 
            // pbcve
            // 
            this.pbcve.BackgroundImage = global::MarketControl.Properties.Resources.c_verde_escura;
            this.pbcve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcve.Location = new System.Drawing.Point(643, 417);
            this.pbcve.Margin = new System.Windows.Forms.Padding(4);
            this.pbcve.Name = "pbcve";
            this.pbcve.Size = new System.Drawing.Size(275, 331);
            this.pbcve.TabIndex = 68;
            this.pbcve.TabStop = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1249, 864);
            this.Controls.Add(this.Casa2v);
            this.Controls.Add(this.Casav);
            this.Controls.Add(this.Nomev);
            this.Controls.Add(this.Tv);
            this.Controls.Add(this.Casa2ve);
            this.Controls.Add(this.Casave);
            this.Controls.Add(this.Nomeve);
            this.Controls.Add(this.Tve);
            this.Controls.Add(this.Casa2m);
            this.Controls.Add(this.Casam);
            this.Controls.Add(this.Nomem);
            this.Controls.Add(this.Tm);
            this.Controls.Add(this.Casa2l);
            this.Controls.Add(this.Casal);
            this.Controls.Add(this.Nomel);
            this.Controls.Add(this.Tl);
            this.Controls.Add(this.Casa2ap);
            this.Controls.Add(this.Casaap);
            this.Controls.Add(this.Nomeap);
            this.Controls.Add(this.Tap);
            this.Controls.Add(this.Casa2ae);
            this.Controls.Add(this.Casaae);
            this.Controls.Add(this.Nomeae);
            this.Controls.Add(this.Tae);
            this.Controls.Add(this.Casa2a);
            this.Controls.Add(this.Casaa);
            this.Controls.Add(this.Nomea);
            this.Controls.Add(this.Ta);
            this.Controls.Add(this.Casa2ac);
            this.Controls.Add(this.Casaac);
            this.Controls.Add(this.Nomeac);
            this.Controls.Add(this.Tac);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pbcap);
            this.Controls.Add(this.pbcv);
            this.Controls.Add(this.pbcae);
            this.Controls.Add(this.pbcac);
            this.Controls.Add(this.pbca);
            this.Controls.Add(this.pbcl);
            this.Controls.Add(this.pbcm);
            this.Controls.Add(this.pbcve);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form4";
            this.Text = "Cartas P1";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbcap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcae)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcac)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcve)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Casa2v;
        private System.Windows.Forms.Label Casav;
        private System.Windows.Forms.Label Nomev;
        private System.Windows.Forms.Label Tv;
        private System.Windows.Forms.Label Casa2ve;
        private System.Windows.Forms.Label Casave;
        private System.Windows.Forms.Label Nomeve;
        private System.Windows.Forms.Label Tve;
        private System.Windows.Forms.Label Casa2m;
        private System.Windows.Forms.Label Casam;
        private System.Windows.Forms.Label Nomem;
        private System.Windows.Forms.Label Tm;
        private System.Windows.Forms.Label Casa2l;
        private System.Windows.Forms.Label Casal;
        private System.Windows.Forms.Label Nomel;
        private System.Windows.Forms.Label Tl;
        private System.Windows.Forms.Label Casa2ap;
        private System.Windows.Forms.Label Casaap;
        private System.Windows.Forms.Label Nomeap;
        private System.Windows.Forms.Label Tap;
        private System.Windows.Forms.Label Casa2ae;
        private System.Windows.Forms.Label Casaae;
        private System.Windows.Forms.Label Nomeae;
        private System.Windows.Forms.Label Tae;
        private System.Windows.Forms.Label Casa2a;
        private System.Windows.Forms.Label Casaa;
        private System.Windows.Forms.Label Nomea;
        private System.Windows.Forms.Label Ta;
        private System.Windows.Forms.Label Casa2ac;
        private System.Windows.Forms.Label Casaac;
        private System.Windows.Forms.Label Nomeac;
        private System.Windows.Forms.Label Tac;
        private System.Windows.Forms.PictureBox pbcap;
        private System.Windows.Forms.PictureBox pbcv;
        private System.Windows.Forms.PictureBox pbcae;
        private System.Windows.Forms.PictureBox pbcac;
        private System.Windows.Forms.PictureBox pbca;
        private System.Windows.Forms.PictureBox pbcl;
        private System.Windows.Forms.PictureBox pbcm;
        private System.Windows.Forms.PictureBox pbcve;
        private System.Windows.Forms.Button button1;
    }
}