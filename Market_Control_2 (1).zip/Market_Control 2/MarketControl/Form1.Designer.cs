﻿namespace MarketControl
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.btnGirar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.lbMoney = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.btnSim = new System.Windows.Forms.Button();
            this.btnNao = new System.Windows.Forms.Button();
            this.compra = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lbPosse1 = new System.Windows.Forms.Label();
            this.lbPosse2 = new System.Windows.Forms.Label();
            this.lbPosse3 = new System.Windows.Forms.Label();
            this.lbPosse4 = new System.Windows.Forms.Label();
            this.lbPosse5 = new System.Windows.Forms.Label();
            this.lbPosse6 = new System.Windows.Forms.Label();
            this.lbPosse7 = new System.Windows.Forms.Label();
            this.lbPosse8 = new System.Windows.Forms.Label();
            this.lbPosse9 = new System.Windows.Forms.Label();
            this.lbPosse10 = new System.Windows.Forms.Label();
            this.lbPosse11 = new System.Windows.Forms.Label();
            this.lbPosse18 = new System.Windows.Forms.Label();
            this.lbPosse19 = new System.Windows.Forms.Label();
            this.lbPosse20 = new System.Windows.Forms.Label();
            this.lbPosse21 = new System.Windows.Forms.Label();
            this.lbPosse22 = new System.Windows.Forms.Label();
            this.lbPosse12 = new System.Windows.Forms.Label();
            this.lbPosse13 = new System.Windows.Forms.Label();
            this.lbPosse14 = new System.Windows.Forms.Label();
            this.lbPosse15 = new System.Windows.Forms.Label();
            this.lbPosse16 = new System.Windows.Forms.Label();
            this.lbPosse17 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnGirarPlayer2 = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.lbMoneyPlayer2 = new System.Windows.Forms.Label();
            this.lbPos1Player2 = new System.Windows.Forms.Label();
            this.lbPos2Player2 = new System.Windows.Forms.Label();
            this.lbPos3Player2 = new System.Windows.Forms.Label();
            this.lbPos4Player2 = new System.Windows.Forms.Label();
            this.lbPos5Player2 = new System.Windows.Forms.Label();
            this.lbPos6Player2 = new System.Windows.Forms.Label();
            this.lbPos7Player2 = new System.Windows.Forms.Label();
            this.lbPos8Player2 = new System.Windows.Forms.Label();
            this.lbPos9Player2 = new System.Windows.Forms.Label();
            this.lbPos10Player2 = new System.Windows.Forms.Label();
            this.lbPos11Player2 = new System.Windows.Forms.Label();
            this.lbPos12Player2 = new System.Windows.Forms.Label();
            this.lbPos13Player2 = new System.Windows.Forms.Label();
            this.lbPos14Player2 = new System.Windows.Forms.Label();
            this.lbPos15Player2 = new System.Windows.Forms.Label();
            this.lbPos16Player2 = new System.Windows.Forms.Label();
            this.lbPos17Player2 = new System.Windows.Forms.Label();
            this.lbPos18Player2 = new System.Windows.Forms.Label();
            this.lbPos19Player2 = new System.Windows.Forms.Label();
            this.lbPos20Player2 = new System.Windows.Forms.Label();
            this.lbPos21Player2 = new System.Windows.Forms.Label();
            this.lbPos22Player2 = new System.Windows.Forms.Label();
            this.lbPos23Player2 = new System.Windows.Forms.Label();
            this.lbPos24Player2 = new System.Windows.Forms.Label();
            this.lbPos25Player2 = new System.Windows.Forms.Label();
            this.lbPos26Player2 = new System.Windows.Forms.Label();
            this.lbPos27Player2 = new System.Windows.Forms.Label();
            this.lbPos29Player2 = new System.Windows.Forms.Label();
            this.lbPos28Player2 = new System.Windows.Forms.Label();
            this.lbPos30Player2 = new System.Windows.Forms.Label();
            this.lbPos31Player2 = new System.Windows.Forms.Label();
            this.lbPos32Player2 = new System.Windows.Forms.Label();
            this.lbPos33Player2 = new System.Windows.Forms.Label();
            this.lbPos34Player2 = new System.Windows.Forms.Label();
            this.lbPos35Player2 = new System.Windows.Forms.Label();
            this.lbPos36Player2 = new System.Windows.Forms.Label();
            this.lbPos37Player2 = new System.Windows.Forms.Label();
            this.lbPos38Player2 = new System.Windows.Forms.Label();
            this.lbPos39Player2 = new System.Windows.Forms.Label();
            this.lbPos40Player2 = new System.Windows.Forms.Label();
            this.compra2 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.btnNao2 = new System.Windows.Forms.Button();
            this.btnSim2 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.pbPlayer2 = new System.Windows.Forms.PictureBox();
            this.pbPlayer1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pbcomunidade = new System.Windows.Forms.PictureBox();
            this.pbsorte = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pbDado = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.compra.SuspendLayout();
            this.panel2.SuspendLayout();
            this.compra2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcomunidade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbsorte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDado)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.btnGirar);
            this.panel1.Controls.Add(this.pbDado);
            this.panel1.Location = new System.Drawing.Point(1161, 722);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(141, 158);
            this.panel1.TabIndex = 0;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(115, 7);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 16);
            this.label46.TabIndex = 123;
            this.label46.Text = "J1";
            // 
            // btnGirar
            // 
            this.btnGirar.Location = new System.Drawing.Point(35, 130);
            this.btnGirar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnGirar.Name = "btnGirar";
            this.btnGirar.Size = new System.Drawing.Size(75, 23);
            this.btnGirar.TabIndex = 1;
            this.btnGirar.Text = "Girar";
            this.btnGirar.UseVisualStyleBackColor = true;
            this.btnGirar.Click += new System.EventHandler(this.btnGirar_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(812, 759);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 42);
            this.label1.TabIndex = 3;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(731, 759);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 42);
            this.label2.TabIndex = 4;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(647, 759);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 42);
            this.label3.TabIndex = 5;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(571, 759);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 42);
            this.label4.TabIndex = 6;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(493, 759);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 42);
            this.label5.TabIndex = 7;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(413, 759);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 42);
            this.label6.TabIndex = 8;
            this.label6.Text = "label6";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(325, 759);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 42);
            this.label7.TabIndex = 9;
            this.label7.Text = "label7";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(248, 759);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 42);
            this.label8.TabIndex = 10;
            this.label8.Text = "label8";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(171, 761);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 41);
            this.label9.TabIndex = 11;
            this.label9.Text = "label9";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(75, 759);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 42);
            this.label10.TabIndex = 12;
            this.label10.Text = "label10";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(75, 690);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 50);
            this.label11.TabIndex = 13;
            this.label11.Text = "label11";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(75, 625);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 50);
            this.label12.TabIndex = 14;
            this.label12.Text = "label12";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(75, 548);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 50);
            this.label13.TabIndex = 15;
            this.label13.Text = "label13";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(75, 478);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 50);
            this.label14.TabIndex = 16;
            this.label14.Text = "label14";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(75, 415);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 50);
            this.label15.TabIndex = 17;
            this.label15.Text = "label15";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(75, 346);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 50);
            this.label16.TabIndex = 18;
            this.label16.Text = "label16";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(75, 283);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 50);
            this.label17.TabIndex = 19;
            this.label17.Text = "label17";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(75, 212);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 50);
            this.label18.TabIndex = 20;
            this.label18.Text = "label18";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(75, 145);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 50);
            this.label19.TabIndex = 21;
            this.label19.Text = "label19";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(77, 71);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 50);
            this.label20.TabIndex = 22;
            this.label20.Text = "label20";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(167, 71);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 39);
            this.label21.TabIndex = 23;
            this.label21.Text = "label21";
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(243, 71);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(48, 50);
            this.label22.TabIndex = 24;
            this.label22.Text = "label22";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(325, 71);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 50);
            this.label23.TabIndex = 25;
            this.label23.Text = "label23";
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(411, 71);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 50);
            this.label24.TabIndex = 26;
            this.label24.Text = "label24";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(489, 71);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 50);
            this.label25.TabIndex = 27;
            this.label25.Text = "label25";
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(567, 71);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 50);
            this.label26.TabIndex = 28;
            this.label26.Text = "label26";
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(647, 71);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 50);
            this.label27.TabIndex = 29;
            this.label27.Text = "label27";
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(723, 71);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 50);
            this.label28.TabIndex = 30;
            this.label28.Text = "label28";
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(808, 71);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(48, 50);
            this.label29.TabIndex = 31;
            this.label29.Text = "label29";
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(891, 71);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(48, 50);
            this.label30.TabIndex = 32;
            this.label30.Text = "label30";
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(891, 145);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 50);
            this.label31.TabIndex = 33;
            this.label31.Text = "label31";
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(891, 213);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 50);
            this.label32.TabIndex = 34;
            this.label32.Text = "label32";
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(891, 283);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(48, 50);
            this.label33.TabIndex = 35;
            this.label33.Text = "label33";
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(891, 346);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(48, 50);
            this.label34.TabIndex = 36;
            this.label34.Text = "label34";
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(891, 415);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 50);
            this.label35.TabIndex = 37;
            this.label35.Text = "label35";
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(891, 478);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(48, 50);
            this.label36.TabIndex = 38;
            this.label36.Text = "label36";
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(891, 548);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(48, 50);
            this.label37.TabIndex = 39;
            this.label37.Text = "label37";
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(891, 614);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(48, 50);
            this.label38.TabIndex = 40;
            this.label38.Text = "label38";
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(891, 677);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(48, 50);
            this.label39.TabIndex = 41;
            this.label39.Text = "label39";
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(896, 751);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(48, 50);
            this.label40.TabIndex = 42;
            this.label40.Text = "label40";
            // 
            // lbMoney
            // 
            this.lbMoney.AutoSize = true;
            this.lbMoney.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMoney.Location = new System.Drawing.Point(1087, 658);
            this.lbMoney.Name = "lbMoney";
            this.lbMoney.Size = new System.Drawing.Size(149, 48);
            this.lbMoney.TabIndex = 43;
            this.lbMoney.Text = "label41";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(40, 9);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(66, 16);
            this.label41.TabIndex = 44;
            this.label41.Text = "Comprar?";
            // 
            // btnSim
            // 
            this.btnSim.Location = new System.Drawing.Point(35, 46);
            this.btnSim.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSim.Name = "btnSim";
            this.btnSim.Size = new System.Drawing.Size(75, 23);
            this.btnSim.TabIndex = 45;
            this.btnSim.Text = "Sim";
            this.btnSim.UseVisualStyleBackColor = true;
            this.btnSim.Click += new System.EventHandler(this.btnSim_Click);
            // 
            // btnNao
            // 
            this.btnNao.Location = new System.Drawing.Point(37, 78);
            this.btnNao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNao.Name = "btnNao";
            this.btnNao.Size = new System.Drawing.Size(75, 23);
            this.btnNao.TabIndex = 46;
            this.btnNao.Text = "Não";
            this.btnNao.UseVisualStyleBackColor = true;
            this.btnNao.Click += new System.EventHandler(this.btnNao_Click);
            // 
            // compra
            // 
            this.compra.BackColor = System.Drawing.Color.Gold;
            this.compra.Controls.Add(this.label45);
            this.compra.Controls.Add(this.label41);
            this.compra.Controls.Add(this.btnNao);
            this.compra.Controls.Add(this.btnSim);
            this.compra.Location = new System.Drawing.Point(1159, 732);
            this.compra.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.compra.Name = "compra";
            this.compra.Size = new System.Drawing.Size(141, 121);
            this.compra.TabIndex = 47;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(112, 11);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(21, 16);
            this.label45.TabIndex = 122;
            this.label45.Text = "J1";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1011, 721);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 50);
            this.button1.TabIndex = 49;
            this.button1.Text = "Cartas P1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.cartas_Click);
            // 
            // lbPosse1
            // 
            this.lbPosse1.Location = new System.Drawing.Point(791, 767);
            this.lbPosse1.Name = "lbPosse1";
            this.lbPosse1.Size = new System.Drawing.Size(77, 89);
            this.lbPosse1.TabIndex = 50;
            // 
            // lbPosse2
            // 
            this.lbPosse2.Location = new System.Drawing.Point(633, 767);
            this.lbPosse2.Name = "lbPosse2";
            this.lbPosse2.Size = new System.Drawing.Size(77, 89);
            this.lbPosse2.TabIndex = 51;
            // 
            // lbPosse3
            // 
            this.lbPosse3.Location = new System.Drawing.Point(397, 767);
            this.lbPosse3.Name = "lbPosse3";
            this.lbPosse3.Size = new System.Drawing.Size(71, 89);
            this.lbPosse3.TabIndex = 52;
            // 
            // lbPosse4
            // 
            this.lbPosse4.Location = new System.Drawing.Point(233, 767);
            this.lbPosse4.Name = "lbPosse4";
            this.lbPosse4.Size = new System.Drawing.Size(77, 89);
            this.lbPosse4.TabIndex = 53;
            // 
            // lbPosse5
            // 
            this.lbPosse5.Location = new System.Drawing.Point(152, 768);
            this.lbPosse5.Name = "lbPosse5";
            this.lbPosse5.Size = new System.Drawing.Size(77, 89);
            this.lbPosse5.TabIndex = 54;
            // 
            // lbPosse6
            // 
            this.lbPosse6.Location = new System.Drawing.Point(24, 676);
            this.lbPosse6.Name = "lbPosse6";
            this.lbPosse6.Size = new System.Drawing.Size(99, 64);
            this.lbPosse6.TabIndex = 55;
            // 
            // lbPosse7
            // 
            this.lbPosse7.Location = new System.Drawing.Point(21, 542);
            this.lbPosse7.Name = "lbPosse7";
            this.lbPosse7.Size = new System.Drawing.Size(101, 65);
            this.lbPosse7.TabIndex = 56;
            // 
            // lbPosse8
            // 
            this.lbPosse8.Location = new System.Drawing.Point(21, 478);
            this.lbPosse8.Name = "lbPosse8";
            this.lbPosse8.Size = new System.Drawing.Size(101, 63);
            this.lbPosse8.TabIndex = 57;
            // 
            // lbPosse9
            // 
            this.lbPosse9.Location = new System.Drawing.Point(15, 337);
            this.lbPosse9.Name = "lbPosse9";
            this.lbPosse9.Size = new System.Drawing.Size(108, 64);
            this.lbPosse9.TabIndex = 58;
            // 
            // lbPosse10
            // 
            this.lbPosse10.Location = new System.Drawing.Point(24, 199);
            this.lbPosse10.Name = "lbPosse10";
            this.lbPosse10.Size = new System.Drawing.Size(99, 64);
            this.lbPosse10.TabIndex = 59;
            // 
            // lbPosse11
            // 
            this.lbPosse11.Location = new System.Drawing.Point(24, 130);
            this.lbPosse11.Name = "lbPosse11";
            this.lbPosse11.Size = new System.Drawing.Size(99, 64);
            this.lbPosse11.TabIndex = 60;
            // 
            // lbPosse18
            // 
            this.lbPosse18.Location = new System.Drawing.Point(899, 130);
            this.lbPosse18.Name = "lbPosse18";
            this.lbPosse18.Size = new System.Drawing.Size(112, 64);
            this.lbPosse18.TabIndex = 61;
            // 
            // lbPosse19
            // 
            this.lbPosse19.Location = new System.Drawing.Point(899, 199);
            this.lbPosse19.Name = "lbPosse19";
            this.lbPosse19.Size = new System.Drawing.Size(112, 64);
            this.lbPosse19.TabIndex = 62;
            // 
            // lbPosse20
            // 
            this.lbPosse20.Location = new System.Drawing.Point(899, 337);
            this.lbPosse20.Name = "lbPosse20";
            this.lbPosse20.Size = new System.Drawing.Size(109, 64);
            this.lbPosse20.TabIndex = 63;
            // 
            // lbPosse21
            // 
            this.lbPosse21.Location = new System.Drawing.Point(899, 542);
            this.lbPosse21.Name = "lbPosse21";
            this.lbPosse21.Size = new System.Drawing.Size(109, 64);
            this.lbPosse21.TabIndex = 64;
            // 
            // lbPosse22
            // 
            this.lbPosse22.Location = new System.Drawing.Point(899, 677);
            this.lbPosse22.Name = "lbPosse22";
            this.lbPosse22.Size = new System.Drawing.Size(109, 63);
            this.lbPosse22.TabIndex = 65;
            // 
            // lbPosse12
            // 
            this.lbPosse12.Location = new System.Drawing.Point(155, 14);
            this.lbPosse12.Name = "lbPosse12";
            this.lbPosse12.Size = new System.Drawing.Size(75, 96);
            this.lbPosse12.TabIndex = 66;
            // 
            // lbPosse13
            // 
            this.lbPosse13.Location = new System.Drawing.Point(312, 14);
            this.lbPosse13.Name = "lbPosse13";
            this.lbPosse13.Size = new System.Drawing.Size(77, 96);
            this.lbPosse13.TabIndex = 67;
            // 
            // lbPosse14
            // 
            this.lbPosse14.Location = new System.Drawing.Point(395, 14);
            this.lbPosse14.Name = "lbPosse14";
            this.lbPosse14.Size = new System.Drawing.Size(75, 96);
            this.lbPosse14.TabIndex = 68;
            // 
            // lbPosse15
            // 
            this.lbPosse15.Location = new System.Drawing.Point(552, 14);
            this.lbPosse15.Name = "lbPosse15";
            this.lbPosse15.Size = new System.Drawing.Size(77, 96);
            this.lbPosse15.TabIndex = 69;
            // 
            // lbPosse16
            // 
            this.lbPosse16.Location = new System.Drawing.Point(633, 14);
            this.lbPosse16.Name = "lbPosse16";
            this.lbPosse16.Size = new System.Drawing.Size(77, 96);
            this.lbPosse16.TabIndex = 70;
            // 
            // lbPosse17
            // 
            this.lbPosse17.Location = new System.Drawing.Point(791, 14);
            this.lbPosse17.Name = "lbPosse17";
            this.lbPosse17.Size = new System.Drawing.Size(77, 96);
            this.lbPosse17.TabIndex = 71;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Violet;
            this.panel2.Controls.Add(this.btnGirarPlayer2);
            this.panel2.Controls.Add(this.label44);
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Location = new System.Drawing.Point(1358, 722);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(144, 158);
            this.panel2.TabIndex = 72;
            // 
            // btnGirarPlayer2
            // 
            this.btnGirarPlayer2.Location = new System.Drawing.Point(35, 129);
            this.btnGirarPlayer2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnGirarPlayer2.Name = "btnGirarPlayer2";
            this.btnGirarPlayer2.Size = new System.Drawing.Size(75, 23);
            this.btnGirarPlayer2.TabIndex = 74;
            this.btnGirarPlayer2.Text = "Girar";
            this.btnGirarPlayer2.UseVisualStyleBackColor = true;
            this.btnGirarPlayer2.Click += new System.EventHandler(this.btnGirarPlayer2_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(109, 4);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(27, 20);
            this.label44.TabIndex = 122;
            this.label44.Text = "J2";
            // 
            // lbMoneyPlayer2
            // 
            this.lbMoneyPlayer2.AutoSize = true;
            this.lbMoneyPlayer2.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMoneyPlayer2.Location = new System.Drawing.Point(1307, 658);
            this.lbMoneyPlayer2.Name = "lbMoneyPlayer2";
            this.lbMoneyPlayer2.Size = new System.Drawing.Size(149, 48);
            this.lbMoneyPlayer2.TabIndex = 73;
            this.lbMoneyPlayer2.Text = "label42";
            // 
            // lbPos1Player2
            // 
            this.lbPos1Player2.Location = new System.Drawing.Point(812, 822);
            this.lbPos1Player2.Name = "lbPos1Player2";
            this.lbPos1Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos1Player2.TabIndex = 75;
            this.lbPos1Player2.Text = "label42";
            // 
            // lbPos2Player2
            // 
            this.lbPos2Player2.Location = new System.Drawing.Point(731, 822);
            this.lbPos2Player2.Name = "lbPos2Player2";
            this.lbPos2Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos2Player2.TabIndex = 76;
            this.lbPos2Player2.Text = "label43";
            // 
            // lbPos3Player2
            // 
            this.lbPos3Player2.Location = new System.Drawing.Point(647, 822);
            this.lbPos3Player2.Name = "lbPos3Player2";
            this.lbPos3Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos3Player2.TabIndex = 77;
            this.lbPos3Player2.Text = "label44";
            // 
            // lbPos4Player2
            // 
            this.lbPos4Player2.Location = new System.Drawing.Point(571, 822);
            this.lbPos4Player2.Name = "lbPos4Player2";
            this.lbPos4Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos4Player2.TabIndex = 78;
            this.lbPos4Player2.Text = "label45";
            // 
            // lbPos5Player2
            // 
            this.lbPos5Player2.Location = new System.Drawing.Point(493, 822);
            this.lbPos5Player2.Name = "lbPos5Player2";
            this.lbPos5Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos5Player2.TabIndex = 79;
            this.lbPos5Player2.Text = "label46";
            // 
            // lbPos6Player2
            // 
            this.lbPos6Player2.Location = new System.Drawing.Point(413, 826);
            this.lbPos6Player2.Name = "lbPos6Player2";
            this.lbPos6Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos6Player2.TabIndex = 80;
            this.lbPos6Player2.Text = "label47";
            // 
            // lbPos7Player2
            // 
            this.lbPos7Player2.Location = new System.Drawing.Point(325, 822);
            this.lbPos7Player2.Name = "lbPos7Player2";
            this.lbPos7Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos7Player2.TabIndex = 81;
            this.lbPos7Player2.Text = "label48";
            // 
            // lbPos8Player2
            // 
            this.lbPos8Player2.Location = new System.Drawing.Point(248, 822);
            this.lbPos8Player2.Name = "lbPos8Player2";
            this.lbPos8Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos8Player2.TabIndex = 82;
            this.lbPos8Player2.Text = "label49";
            // 
            // lbPos9Player2
            // 
            this.lbPos9Player2.Location = new System.Drawing.Point(171, 822);
            this.lbPos9Player2.Name = "lbPos9Player2";
            this.lbPos9Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos9Player2.TabIndex = 83;
            this.lbPos9Player2.Text = "label50";
            // 
            // lbPos10Player2
            // 
            this.lbPos10Player2.Location = new System.Drawing.Point(28, 822);
            this.lbPos10Player2.Name = "lbPos10Player2";
            this.lbPos10Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos10Player2.TabIndex = 84;
            this.lbPos10Player2.Text = "label51";
            // 
            // lbPos11Player2
            // 
            this.lbPos11Player2.Location = new System.Drawing.Point(25, 697);
            this.lbPos11Player2.Name = "lbPos11Player2";
            this.lbPos11Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos11Player2.TabIndex = 85;
            this.lbPos11Player2.Text = "label52";
            // 
            // lbPos12Player2
            // 
            this.lbPos12Player2.Location = new System.Drawing.Point(28, 625);
            this.lbPos12Player2.Name = "lbPos12Player2";
            this.lbPos12Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos12Player2.TabIndex = 86;
            this.lbPos12Player2.Text = "label53";
            // 
            // lbPos13Player2
            // 
            this.lbPos13Player2.Location = new System.Drawing.Point(25, 548);
            this.lbPos13Player2.Name = "lbPos13Player2";
            this.lbPos13Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos13Player2.TabIndex = 87;
            this.lbPos13Player2.Text = "label54";
            // 
            // lbPos14Player2
            // 
            this.lbPos14Player2.Location = new System.Drawing.Point(25, 478);
            this.lbPos14Player2.Name = "lbPos14Player2";
            this.lbPos14Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos14Player2.TabIndex = 88;
            this.lbPos14Player2.Text = "label55";
            // 
            // lbPos15Player2
            // 
            this.lbPos15Player2.Location = new System.Drawing.Point(25, 415);
            this.lbPos15Player2.Name = "lbPos15Player2";
            this.lbPos15Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos15Player2.TabIndex = 89;
            this.lbPos15Player2.Text = "label56";
            // 
            // lbPos16Player2
            // 
            this.lbPos16Player2.Location = new System.Drawing.Point(25, 346);
            this.lbPos16Player2.Name = "lbPos16Player2";
            this.lbPos16Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos16Player2.TabIndex = 90;
            this.lbPos16Player2.Text = "label57";
            // 
            // lbPos17Player2
            // 
            this.lbPos17Player2.Location = new System.Drawing.Point(25, 283);
            this.lbPos17Player2.Name = "lbPos17Player2";
            this.lbPos17Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos17Player2.TabIndex = 91;
            this.lbPos17Player2.Text = "label58";
            // 
            // lbPos18Player2
            // 
            this.lbPos18Player2.Location = new System.Drawing.Point(25, 213);
            this.lbPos18Player2.Name = "lbPos18Player2";
            this.lbPos18Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos18Player2.TabIndex = 92;
            this.lbPos18Player2.Text = "label59";
            // 
            // lbPos19Player2
            // 
            this.lbPos19Player2.Location = new System.Drawing.Point(25, 145);
            this.lbPos19Player2.Name = "lbPos19Player2";
            this.lbPos19Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos19Player2.TabIndex = 93;
            this.lbPos19Player2.Text = "label60";
            // 
            // lbPos20Player2
            // 
            this.lbPos20Player2.Location = new System.Drawing.Point(28, 25);
            this.lbPos20Player2.Name = "lbPos20Player2";
            this.lbPos20Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos20Player2.TabIndex = 94;
            this.lbPos20Player2.Text = "label61";
            // 
            // lbPos21Player2
            // 
            this.lbPos21Player2.Location = new System.Drawing.Point(167, 14);
            this.lbPos21Player2.Name = "lbPos21Player2";
            this.lbPos21Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos21Player2.TabIndex = 95;
            this.lbPos21Player2.Text = "label62";
            // 
            // lbPos22Player2
            // 
            this.lbPos22Player2.Location = new System.Drawing.Point(243, 25);
            this.lbPos22Player2.Name = "lbPos22Player2";
            this.lbPos22Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos22Player2.TabIndex = 96;
            this.lbPos22Player2.Text = "label63";
            // 
            // lbPos23Player2
            // 
            this.lbPos23Player2.Location = new System.Drawing.Point(325, 25);
            this.lbPos23Player2.Name = "lbPos23Player2";
            this.lbPos23Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos23Player2.TabIndex = 97;
            this.lbPos23Player2.Text = "label64";
            // 
            // lbPos24Player2
            // 
            this.lbPos24Player2.Location = new System.Drawing.Point(411, 25);
            this.lbPos24Player2.Name = "lbPos24Player2";
            this.lbPos24Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos24Player2.TabIndex = 98;
            this.lbPos24Player2.Text = "label65";
            // 
            // lbPos25Player2
            // 
            this.lbPos25Player2.Location = new System.Drawing.Point(489, 25);
            this.lbPos25Player2.Name = "lbPos25Player2";
            this.lbPos25Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos25Player2.TabIndex = 99;
            this.lbPos25Player2.Text = "label66";
            // 
            // lbPos26Player2
            // 
            this.lbPos26Player2.Location = new System.Drawing.Point(567, 25);
            this.lbPos26Player2.Name = "lbPos26Player2";
            this.lbPos26Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos26Player2.TabIndex = 100;
            this.lbPos26Player2.Text = "label67";
            // 
            // lbPos27Player2
            // 
            this.lbPos27Player2.Location = new System.Drawing.Point(647, 25);
            this.lbPos27Player2.Name = "lbPos27Player2";
            this.lbPos27Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos27Player2.TabIndex = 101;
            this.lbPos27Player2.Text = "label68";
            // 
            // lbPos29Player2
            // 
            this.lbPos29Player2.Location = new System.Drawing.Point(808, 25);
            this.lbPos29Player2.Name = "lbPos29Player2";
            this.lbPos29Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos29Player2.TabIndex = 102;
            this.lbPos29Player2.Text = "label69";
            // 
            // lbPos28Player2
            // 
            this.lbPos28Player2.Location = new System.Drawing.Point(723, 25);
            this.lbPos28Player2.Name = "lbPos28Player2";
            this.lbPos28Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos28Player2.TabIndex = 102;
            this.lbPos28Player2.Text = "label69";
            // 
            // lbPos30Player2
            // 
            this.lbPos30Player2.Location = new System.Drawing.Point(947, 25);
            this.lbPos30Player2.Name = "lbPos30Player2";
            this.lbPos30Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos30Player2.TabIndex = 103;
            this.lbPos30Player2.Text = "label71";
            // 
            // lbPos31Player2
            // 
            this.lbPos31Player2.Location = new System.Drawing.Point(947, 145);
            this.lbPos31Player2.Name = "lbPos31Player2";
            this.lbPos31Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos31Player2.TabIndex = 104;
            this.lbPos31Player2.Text = "label72";
            // 
            // lbPos32Player2
            // 
            this.lbPos32Player2.Location = new System.Drawing.Point(947, 213);
            this.lbPos32Player2.Name = "lbPos32Player2";
            this.lbPos32Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos32Player2.TabIndex = 105;
            this.lbPos32Player2.Text = "label73";
            // 
            // lbPos33Player2
            // 
            this.lbPos33Player2.Location = new System.Drawing.Point(947, 283);
            this.lbPos33Player2.Name = "lbPos33Player2";
            this.lbPos33Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos33Player2.TabIndex = 106;
            this.lbPos33Player2.Text = "label74";
            // 
            // lbPos34Player2
            // 
            this.lbPos34Player2.Location = new System.Drawing.Point(947, 353);
            this.lbPos34Player2.Name = "lbPos34Player2";
            this.lbPos34Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos34Player2.TabIndex = 107;
            this.lbPos34Player2.Text = "label75";
            // 
            // lbPos35Player2
            // 
            this.lbPos35Player2.Location = new System.Drawing.Point(947, 415);
            this.lbPos35Player2.Name = "lbPos35Player2";
            this.lbPos35Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos35Player2.TabIndex = 108;
            this.lbPos35Player2.Text = "label76";
            // 
            // lbPos36Player2
            // 
            this.lbPos36Player2.Location = new System.Drawing.Point(947, 485);
            this.lbPos36Player2.Name = "lbPos36Player2";
            this.lbPos36Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos36Player2.TabIndex = 109;
            this.lbPos36Player2.Text = "label77";
            // 
            // lbPos37Player2
            // 
            this.lbPos37Player2.Location = new System.Drawing.Point(947, 555);
            this.lbPos37Player2.Name = "lbPos37Player2";
            this.lbPos37Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos37Player2.TabIndex = 110;
            this.lbPos37Player2.Text = "label78";
            // 
            // lbPos38Player2
            // 
            this.lbPos38Player2.Location = new System.Drawing.Point(947, 625);
            this.lbPos38Player2.Name = "lbPos38Player2";
            this.lbPos38Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos38Player2.TabIndex = 111;
            this.lbPos38Player2.Text = "label79";
            // 
            // lbPos39Player2
            // 
            this.lbPos39Player2.Location = new System.Drawing.Point(947, 684);
            this.lbPos39Player2.Name = "lbPos39Player2";
            this.lbPos39Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos39Player2.TabIndex = 112;
            this.lbPos39Player2.Text = "label80";
            // 
            // lbPos40Player2
            // 
            this.lbPos40Player2.Location = new System.Drawing.Point(955, 810);
            this.lbPos40Player2.Name = "lbPos40Player2";
            this.lbPos40Player2.Size = new System.Drawing.Size(44, 43);
            this.lbPos40Player2.TabIndex = 113;
            this.lbPos40Player2.Text = "label81";
            // 
            // compra2
            // 
            this.compra2.BackColor = System.Drawing.Color.Violet;
            this.compra2.Controls.Add(this.label43);
            this.compra2.Controls.Add(this.btnNao2);
            this.compra2.Controls.Add(this.btnSim2);
            this.compra2.Controls.Add(this.label42);
            this.compra2.Location = new System.Drawing.Point(1341, 737);
            this.compra2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.compra2.Name = "compra2";
            this.compra2.Size = new System.Drawing.Size(161, 117);
            this.compra2.TabIndex = 114;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(132, 4);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(21, 16);
            this.label43.TabIndex = 121;
            this.label43.Text = "J2";
            // 
            // btnNao2
            // 
            this.btnNao2.Location = new System.Drawing.Point(52, 80);
            this.btnNao2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNao2.Name = "btnNao2";
            this.btnNao2.Size = new System.Drawing.Size(75, 23);
            this.btnNao2.TabIndex = 115;
            this.btnNao2.Text = "Não";
            this.btnNao2.UseVisualStyleBackColor = true;
            this.btnNao2.Click += new System.EventHandler(this.btnNao2_Click);
            // 
            // btnSim2
            // 
            this.btnSim2.Location = new System.Drawing.Point(52, 55);
            this.btnSim2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSim2.Name = "btnSim2";
            this.btnSim2.Size = new System.Drawing.Size(75, 23);
            this.btnSim2.TabIndex = 115;
            this.btnSim2.Text = "Sim";
            this.btnSim2.UseVisualStyleBackColor = true;
            this.btnSim2.Click += new System.EventHandler(this.btnSim2_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(49, 6);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(66, 16);
            this.label42.TabIndex = 115;
            this.label42.Text = "Comprar?";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Violet;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1011, 817);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 50);
            this.button2.TabIndex = 117;
            this.button2.Text = "Cartas P2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1447, 11);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 118;
            this.button3.Text = "SAIR";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label47.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(1031, 618);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(491, 25);
            this.label47.TabIndex = 121;
            this.label47.Text = "label47";
            // 
            // pbPlayer2
            // 
            this.pbPlayer2.Image = global::MarketControl.Properties.Resources.avatar2;
            this.pbPlayer2.Location = new System.Drawing.Point(949, 798);
            this.pbPlayer2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbPlayer2.Name = "pbPlayer2";
            this.pbPlayer2.Size = new System.Drawing.Size(49, 55);
            this.pbPlayer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPlayer2.TabIndex = 74;
            this.pbPlayer2.TabStop = false;
            // 
            // pbPlayer1
            // 
            this.pbPlayer1.Image = global::MarketControl.Properties.Resources.avatar;
            this.pbPlayer1.Location = new System.Drawing.Point(895, 751);
            this.pbPlayer1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbPlayer1.Name = "pbPlayer1";
            this.pbPlayer1.Size = new System.Drawing.Size(51, 55);
            this.pbPlayer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPlayer1.TabIndex = 2;
            this.pbPlayer1.TabStop = false;
            this.pbPlayer1.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MarketControl.Properties.Resources.board1;
            this.pictureBox1.Location = new System.Drawing.Point(15, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(996, 850);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::MarketControl.Properties.Resources.katittos;
            this.pictureBox4.Location = new System.Drawing.Point(1445, 653);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(57, 64);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 120;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::MarketControl.Properties.Resources.katittos;
            this.pictureBox2.Location = new System.Drawing.Point(1229, 653);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(57, 64);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 119;
            this.pictureBox2.TabStop = false;
            // 
            // pbcomunidade
            // 
            this.pbcomunidade.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbcomunidade.Location = new System.Drawing.Point(1031, 321);
            this.pbcomunidade.Margin = new System.Windows.Forms.Padding(4);
            this.pbcomunidade.Name = "pbcomunidade";
            this.pbcomunidade.Size = new System.Drawing.Size(491, 286);
            this.pbcomunidade.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbcomunidade.TabIndex = 116;
            this.pbcomunidade.TabStop = false;
            // 
            // pbsorte
            // 
            this.pbsorte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbsorte.Location = new System.Drawing.Point(1031, 40);
            this.pbsorte.Margin = new System.Windows.Forms.Padding(4);
            this.pbsorte.Name = "pbsorte";
            this.pbsorte.Size = new System.Drawing.Size(491, 270);
            this.pbsorte.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbsorte.TabIndex = 115;
            this.pbsorte.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::MarketControl.Properties.Resources.dado;
            this.pictureBox3.Location = new System.Drawing.Point(21, 9);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 94);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 74;
            this.pictureBox3.TabStop = false;
            // 
            // pbDado
            // 
            this.pbDado.Image = global::MarketControl.Properties.Resources.dado;
            this.pbDado.Location = new System.Drawing.Point(16, 9);
            this.pbDado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbDado.Name = "pbDado";
            this.pbDado.Size = new System.Drawing.Size(108, 101);
            this.pbDado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDado.TabIndex = 0;
            this.pbDado.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1541, 886);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.pbPlayer2);
            this.Controls.Add(this.pbPlayer1);
            this.Controls.Add(this.lbPosse17);
            this.Controls.Add(this.lbPosse16);
            this.Controls.Add(this.lbPosse15);
            this.Controls.Add(this.lbPosse14);
            this.Controls.Add(this.lbPosse13);
            this.Controls.Add(this.lbPosse12);
            this.Controls.Add(this.lbPosse22);
            this.Controls.Add(this.lbPosse21);
            this.Controls.Add(this.lbPosse20);
            this.Controls.Add(this.lbPosse19);
            this.Controls.Add(this.lbPosse18);
            this.Controls.Add(this.lbPosse11);
            this.Controls.Add(this.lbPosse10);
            this.Controls.Add(this.lbPosse9);
            this.Controls.Add(this.lbPosse8);
            this.Controls.Add(this.lbPosse7);
            this.Controls.Add(this.lbPosse6);
            this.Controls.Add(this.lbPosse5);
            this.Controls.Add(this.lbPosse4);
            this.Controls.Add(this.lbPosse3);
            this.Controls.Add(this.lbPosse2);
            this.Controls.Add(this.lbPosse1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pbcomunidade);
            this.Controls.Add(this.pbsorte);
            this.Controls.Add(this.compra2);
            this.Controls.Add(this.lbPos39Player2);
            this.Controls.Add(this.lbPos38Player2);
            this.Controls.Add(this.lbPos37Player2);
            this.Controls.Add(this.lbPos36Player2);
            this.Controls.Add(this.lbPos35Player2);
            this.Controls.Add(this.lbPos34Player2);
            this.Controls.Add(this.lbPos33Player2);
            this.Controls.Add(this.lbPos32Player2);
            this.Controls.Add(this.lbPos31Player2);
            this.Controls.Add(this.lbPos30Player2);
            this.Controls.Add(this.lbPos28Player2);
            this.Controls.Add(this.lbPos29Player2);
            this.Controls.Add(this.lbPos27Player2);
            this.Controls.Add(this.lbPos26Player2);
            this.Controls.Add(this.lbPos25Player2);
            this.Controls.Add(this.lbPos24Player2);
            this.Controls.Add(this.lbPos23Player2);
            this.Controls.Add(this.lbPos22Player2);
            this.Controls.Add(this.lbPos21Player2);
            this.Controls.Add(this.lbPos20Player2);
            this.Controls.Add(this.lbPos19Player2);
            this.Controls.Add(this.lbPos18Player2);
            this.Controls.Add(this.lbPos17Player2);
            this.Controls.Add(this.lbPos16Player2);
            this.Controls.Add(this.lbPos15Player2);
            this.Controls.Add(this.lbPos14Player2);
            this.Controls.Add(this.lbPos13Player2);
            this.Controls.Add(this.lbPos12Player2);
            this.Controls.Add(this.lbPos11Player2);
            this.Controls.Add(this.lbPos10Player2);
            this.Controls.Add(this.lbPos9Player2);
            this.Controls.Add(this.lbPos8Player2);
            this.Controls.Add(this.lbPos7Player2);
            this.Controls.Add(this.lbPos6Player2);
            this.Controls.Add(this.lbPos5Player2);
            this.Controls.Add(this.lbPos4Player2);
            this.Controls.Add(this.lbPos3Player2);
            this.Controls.Add(this.lbPos2Player2);
            this.Controls.Add(this.lbPos1Player2);
            this.Controls.Add(this.lbMoneyPlayer2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbMoney);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbPos40Player2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.compra);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Market Control";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.compra.ResumeLayout(false);
            this.compra.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.compra2.ResumeLayout(false);
            this.compra2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcomunidade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbsorte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnGirar;
        private System.Windows.Forms.PictureBox pbDado;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbPlayer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label lbMoney;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button btnSim;
        private System.Windows.Forms.Button btnNao;
        private System.Windows.Forms.Panel compra;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbPosse1;
        private System.Windows.Forms.Label lbPosse2;
        private System.Windows.Forms.Label lbPosse3;
        private System.Windows.Forms.Label lbPosse4;
        private System.Windows.Forms.Label lbPosse5;
        private System.Windows.Forms.Label lbPosse6;
        private System.Windows.Forms.Label lbPosse7;
        private System.Windows.Forms.Label lbPosse8;
        private System.Windows.Forms.Label lbPosse9;
        private System.Windows.Forms.Label lbPosse10;
        private System.Windows.Forms.Label lbPosse11;
        private System.Windows.Forms.Label lbPosse18;
        private System.Windows.Forms.Label lbPosse19;
        private System.Windows.Forms.Label lbPosse20;
        private System.Windows.Forms.Label lbPosse21;
        private System.Windows.Forms.Label lbPosse22;
        private System.Windows.Forms.Label lbPosse12;
        private System.Windows.Forms.Label lbPosse13;
        private System.Windows.Forms.Label lbPosse14;
        private System.Windows.Forms.Label lbPosse15;
        private System.Windows.Forms.Label lbPosse16;
        private System.Windows.Forms.Label lbPosse17;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnGirarPlayer2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lbMoneyPlayer2;
        private System.Windows.Forms.PictureBox pbPlayer2;
        private System.Windows.Forms.Label lbPos1Player2;
        private System.Windows.Forms.Label lbPos2Player2;
        private System.Windows.Forms.Label lbPos3Player2;
        private System.Windows.Forms.Label lbPos4Player2;
        private System.Windows.Forms.Label lbPos5Player2;
        private System.Windows.Forms.Label lbPos6Player2;
        private System.Windows.Forms.Label lbPos7Player2;
        private System.Windows.Forms.Label lbPos8Player2;
        private System.Windows.Forms.Label lbPos9Player2;
        private System.Windows.Forms.Label lbPos10Player2;
        private System.Windows.Forms.Label lbPos11Player2;
        private System.Windows.Forms.Label lbPos12Player2;
        private System.Windows.Forms.Label lbPos13Player2;
        private System.Windows.Forms.Label lbPos14Player2;
        private System.Windows.Forms.Label lbPos15Player2;
        private System.Windows.Forms.Label lbPos16Player2;
        private System.Windows.Forms.Label lbPos17Player2;
        private System.Windows.Forms.Label lbPos18Player2;
        private System.Windows.Forms.Label lbPos19Player2;
        private System.Windows.Forms.Label lbPos20Player2;
        private System.Windows.Forms.Label lbPos21Player2;
        private System.Windows.Forms.Label lbPos22Player2;
        private System.Windows.Forms.Label lbPos23Player2;
        private System.Windows.Forms.Label lbPos24Player2;
        private System.Windows.Forms.Label lbPos25Player2;
        private System.Windows.Forms.Label lbPos26Player2;
        private System.Windows.Forms.Label lbPos27Player2;
        private System.Windows.Forms.Label lbPos29Player2;
        private System.Windows.Forms.Label lbPos28Player2;
        private System.Windows.Forms.Label lbPos30Player2;
        private System.Windows.Forms.Label lbPos31Player2;
        private System.Windows.Forms.Label lbPos32Player2;
        private System.Windows.Forms.Label lbPos33Player2;
        private System.Windows.Forms.Label lbPos34Player2;
        private System.Windows.Forms.Label lbPos35Player2;
        private System.Windows.Forms.Label lbPos36Player2;
        private System.Windows.Forms.Label lbPos37Player2;
        private System.Windows.Forms.Label lbPos38Player2;
        private System.Windows.Forms.Label lbPos39Player2;
        private System.Windows.Forms.Label lbPos40Player2;
        private System.Windows.Forms.Panel compra2;
        private System.Windows.Forms.Button btnNao2;
        private System.Windows.Forms.Button btnSim2;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.PictureBox pbsorte;
        private System.Windows.Forms.PictureBox pbcomunidade;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label47;
    }
}

