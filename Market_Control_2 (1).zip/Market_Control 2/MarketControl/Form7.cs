﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarketControl
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            if (Program.imagem[0] == 1 && Program.winloss == 2)
            {
                pictureBox1.Image = MarketControl.Properties.Resources.Player1_1_;
                label1.Text = "JOGADOR 1";
            }
            else if (Program.imagem[1] == 2 && Program.winloss == 2)
            {
                pictureBox1.Image = MarketControl.Properties.Resources.Player1_2_;
                label1.Text = "JOGADOR 1";
            }
            if (Program.imagem[2] == 3 && Program.winloss == 1)
            {
                pictureBox1.Image = MarketControl.Properties.Resources.Player2_1_;
                label1.Text = "JOGADOR 2";
            }
            else if (Program.imagem[3] == 4 && Program.winloss == 1)
            {
                pictureBox1.Image = MarketControl.Properties.Resources.Player2_2_;
                label1.Text = "JOGADOR 2";
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Form form2 = new Form2();
            form2.Show();
            this.Hide();
        }
    }
}
