﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace MarketControl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
            label11.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
            label16.Visible = false;
            label17.Visible = false;
            label18.Visible = false;
            label19.Visible = false;
            label20.Visible = false;
            label21.Visible = false;
            label22.Visible = false;
            label23.Visible = false;
            label24.Visible = false;
            label25.Visible = false;
            label26.Visible = false;
            label27.Visible = false;
            label28.Visible = false;
            label29.Visible = false;
            label30.Visible = false;
            label31.Visible = false;
            label32.Visible = false;
            label33.Visible = false;
            label34.Visible = false;
            label35.Visible = false;
            label36.Visible = false;
            label37.Visible = false;
            label38.Visible = false;
            label39.Visible = false;
            label40.Visible = false;

            lbPos1Player2.Visible = false;
            lbPos2Player2.Visible = false;
            lbPos3Player2.Visible = false;
            lbPos4Player2.Visible = false;
            lbPos5Player2.Visible = false;
            lbPos6Player2.Visible = false;
            lbPos7Player2.Visible = false;
            lbPos8Player2.Visible = false;
            lbPos9Player2.Visible = false;
            lbPos10Player2.Visible = false;
            lbPos11Player2.Visible = false;
            lbPos12Player2.Visible = false;
            lbPos13Player2.Visible = false;
            lbPos14Player2.Visible = false;
            lbPos15Player2.Visible = false;
            lbPos16Player2.Visible = false;
            lbPos17Player2.Visible = false;
            lbPos18Player2.Visible = false;
            lbPos19Player2.Visible = false;
            lbPos20Player2.Visible = false;
            lbPos21Player2.Visible = false;
            lbPos22Player2.Visible = false;
            lbPos23Player2.Visible = false;
            lbPos24Player2.Visible = false;
            lbPos25Player2.Visible = false;
            lbPos26Player2.Visible = false;
            lbPos27Player2.Visible = false;
            lbPos28Player2.Visible = false;
            lbPos29Player2.Visible = false;
            lbPos30Player2.Visible = false;
            lbPos31Player2.Visible = false;
            lbPos32Player2.Visible = false;
            lbPos33Player2.Visible = false;
            lbPos34Player2.Visible = false;
            lbPos35Player2.Visible = false;
            lbPos36Player2.Visible = false;
            lbPos37Player2.Visible = false;
            lbPos38Player2.Visible = false;
            lbPos39Player2.Visible = false;
            lbPos40Player2.Visible = false;

            lbPosse1.Visible = false;
            lbPosse2.Visible = false;
            lbPosse3.Visible = false;
            lbPosse4.Visible = false;
            lbPosse5.Visible = false;
            lbPosse6.Visible = false;
            lbPosse7.Visible = false;
            lbPosse8.Visible = false;
            lbPosse9.Visible = false;
            lbPosse10.Visible = false;
            lbPosse11.Visible = false;
            lbPosse12.Visible = false;
            lbPosse13.Visible = false;
            lbPosse14.Visible = false;
            lbPosse15.Visible = false;
            lbPosse16.Visible = false;
            lbPosse17.Visible = false;
            lbPosse18.Visible = false;
            lbPosse19.Visible = false;
            lbPosse20.Visible = false;
            lbPosse21.Visible = false;
            lbPosse22.Visible = false;
            
            compra.Visible = false;
            compra2.Visible = false;

            label47.Visible = false;

            panel2.Visible = false;


            if (Program.imagem[0] == 1)
            {
                pbPlayer1.Image = MarketControl.Properties.Resources.Player1_1_;
            }
            else if (Program.imagem[1] == 2)
            {
                pbPlayer1.Image = MarketControl.Properties.Resources.Player1_2_;
            }
            if (Program.imagem[2] == 3)
            {
                pbPlayer2.Image = MarketControl.Properties.Resources.Player2_1_;
            }
            else if (Program.imagem[3] == 4)
            {
                pbPlayer2.Image = MarketControl.Properties.Resources.Player2_2_;
            }
            

            Program.money2 = 1500;
            Program.money = 1500;
            lbMoneyPlayer2.Text = Program.money2.ToString();
            lbMoney.Text = Program.money.ToString();

            pbPlayer1.Location = label40.Location;
            pbPlayer2.Location = lbPos40Player2.Location;

            Program.pos = 0;
            Program.pos2 = 0;
            //panel1.Visible = false;
        }

        int[] rent1 = new int[] { 50, 100, 150, 200, 250, 300, 350, 400 };
        int[] lim = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
        int volta = 1;
        int disa = 1; // disapear
        int disa1 = 1;
        
        private void btnGirar_Click(object sender, EventArgs e)
        {
            int back = 0;
            Random random = new Random();
            int dado = random.Next(1,7);

           // dado = 1;
            
            if (dado == 1)
            {
                pbDado.Image = MarketControl.Properties.Resources.dado1;
                Program.pos = Program.pos + 1;
            }
            if (dado == 2)
            {
                pbDado.Image = MarketControl.Properties.Resources.dado2;

                Program.pos = Program.pos + 2;
            }
            if (dado == 3)
            {
                pbDado.Image = MarketControl.Properties.Resources.dado3;
                Program.pos = Program.pos + 3;
            }
            if (dado == 4)
            {
                pbDado.Image = MarketControl.Properties.Resources.dado4;
                Program.pos = Program.pos + 4;
            }
            if (dado == 5)
            {
                pbDado.Image = MarketControl.Properties.Resources.dado5;
                Program.pos = Program.pos + 5;
            }
            if (dado == 6)
            {
                pbDado.Image = MarketControl.Properties.Resources.dado6;
                Program.pos = Program.pos += 6;
            }

        //----------------Posicao-----------------------------

        Inicio:;
            if (Program.money <= -1)
            {
                Program.winloss = 1;
                Form form7 = new Form7();
                form7.Show();
                this.Hide();
            }
            if (Program.pos == 1)
            {
                pbPlayer1.Location = label1.Location;
                if (lim[0] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if(lim[0] == 0 && lbPosse1.BackColor == Color.Violet)
                {
                    Program.money -= rent1[0];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[0];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[0] + " katittos";
                }
                if (lbPosse1.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 2)
            {
                pbPlayer1.Location = label2.Location;
                pbcomunidade.Visible = true;
                Random r = new Random();
                int com = r.Next(1,6);
                if (com == 1)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade1;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                if (com == 2)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade2;
                    Program.money = Program.money - 50;
                    lbMoney.Text = Program.money.ToString(); 
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 50 katittos";
                }
                if (com == 3)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade3_1_;
                    back = 1;
                }
                if (com == 4)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade4;
                    Program.money = Program.money + 25;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 25 katittos";
                }
                if (com == 5)// MUDAR
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade5_1_; 
                    Program.money = Program.money + 50;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 50 katittos";
                }
                disa = 2;
            }
            if (Program.pos == 3)
            {
                pbPlayer1.Location = label3.Location;
                if (lim[1] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if(lim[1] == 0 && lbPosse2.BackColor == Color.Violet)
                {
                    Program.money -= rent1[0];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[0];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[0] + " katittos";
                }
                if (lbPosse2.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 4)
            {
                pbPlayer1.Location = label4.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 5)
            {
                pbPlayer1.Location = label5.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 6)
            {
                pbPlayer1.Location = label6.Location;
                if (lim[2] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if (lim[2] == 0 && lbPosse3.BackColor == Color.Violet)
                {
                    Program.money -= rent1[1];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[1];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[1] + " katittos";
                }
                if (lbPosse3.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 7)
            {
                pbPlayer1.Location = label7.Location;
                panel1.Visible = false;
                panel2.Visible = true;
                pbsorte.Visible = true; 
                Random r = new Random();
                int sorte = r.Next(1,6);
                if (sorte == 1)//MUDAR
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte1_1_;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                if (sorte == 2)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte2;
                    Program.money = Program.money + 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 100 katittos";
                }
                if (sorte == 3)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte3_1_;
                    Program.money = Program.money + 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 100 katittos";
                }
                if (sorte == 4)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte4;
                    Program.money = Program.money + 150;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 150 katittos";
                }
                if (sorte == 5)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte5;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                disa = 2;
            }
            if (Program.pos == 8)
            {
                pbPlayer1.Location = label8.Location;
                if (lim[3] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if(lim[3] == 0 && lbPosse4.BackColor == Color.Violet)
                {
                    Program.money -= rent1[1];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[1];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[1] + " katittos";
                }
                if (lbPosse4.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 9)
            {
                pbPlayer1.Location = label9.Location;
                if (lim[4] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true;  
                }
                 if (lim[4] == 0 && lbPosse5.BackColor == Color.Violet)
                {
                    Program.money -= rent1[1];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[1];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true; 
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[1] + " katittos";
                }
                if (lbPosse5.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 10)
            {
                pbPlayer1.Location = label10.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 11)
            {
                pbPlayer1.Location = label11.Location;
                if (lim[5] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[5] == 0 && lbPosse6.BackColor == Color.Violet)
                {
                    Program.money -= rent1[2];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[2];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[2] + " katittos";
                }
                if (lbPosse6.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 12)
            {
                pbPlayer1.Location = label12.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 13)
            {
                pbPlayer1.Location = label13.Location;
                if (lim[6] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[6] == 0 && lbPosse7.BackColor == Color.Violet)
                {
                    Program.money -= rent1[2];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[2];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[2] + " katittos";
                }
                if (lbPosse7.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 14)
            {
                pbPlayer1.Location = label14.Location;
                if (lim[7] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if (lim[7] == 0 && lbPosse8.BackColor == Color.Violet)
                {
                    Program.money -= rent1[2];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[2];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[2] + " katittos";
                }
                if (lbPosse8.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 15)
            {
                pbPlayer1.Location = label15.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 16)
            {
                pbPlayer1.Location = label16.Location;
                if (lim[8] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[8] == 0 && lbPosse9.BackColor == Color.Violet)
                {
                    Program.money -= rent1[3];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[3];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[3] + " katittos";
                }
                if (lbPosse9.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 17)
            {
                pbPlayer1.Location = label17.Location;
                pbcomunidade.Visible = true;
                Random r = new Random();
                int com = r.Next(1, 6);
                if (com == 1)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade1;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                if (com == 2)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade2;
                    Program.money = Program.money - 50;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 50 katittos";
                }
                if (com == 3)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade3_1_;
                    back = 1;
                }
                if (com == 4)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade4;
                    Program.money = Program.money + 25;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 25 katittos";
                }
                if (com == 5)// MUDAR
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade5_1_;
                    Program.money = Program.money + 50;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 50 katittos";
                }
                disa = 2;
            }
            if (Program.pos == 18)
            {
                pbPlayer1.Location = label18.Location;
                if (lim[9] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if (lim[9] == 0 && lbPosse10.BackColor == Color.Violet)
                {
                    Program.money -= rent1[3];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[3];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[3] + " katittos";
                }
                if (lbPosse10.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 19)
            {
                pbPlayer1.Location = label19.Location;
                if (lim[10] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if (lim[10] == 0 && lbPosse11.BackColor == Color.Violet)
                {
                    Program.money -= rent1[3];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[3];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[3] + " katittos";
                }
                if (lbPosse11.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 20)
            {
                pbPlayer1.Location = label20.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 21)
            {
                pbPlayer1.Location = label21.Location;
                if (lim[11] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if(lim[11] == 0 && lbPosse12.BackColor == Color.Violet)
                {
                    Program.money -= rent1[4];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[4];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[4] + " katittos";
                }
                if (lbPosse12.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 22)
            {
                pbPlayer1.Location = label22.Location;
                panel1.Visible = false;
                panel2.Visible = true;
                pbsorte.Visible = true;
                Random r = new Random();
                int sorte = r.Next(1, 6);
                if (sorte == 1)//MUDAR
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte1_1_;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                if (sorte == 2)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte2;
                    Program.money = Program.money + 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 100 katittos";
                }
                if (sorte == 3)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte3_1_;
                    Program.money = Program.money + 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 100 katittos";
                }
                if (sorte == 4)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte4;
                    Program.money = Program.money + 150;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 150 katittos";
                }
                if (sorte == 5)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte5;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                disa = 2;
            }
            if (Program.pos == 23)
            {
                pbPlayer1.Location = label23.Location;
                if (lim[12] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if(lim[12] == 0 && lbPosse13.BackColor == Color.Violet)
                {
                    Program.money -= rent1[4];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[4];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[4] + " katittos";
                }
                if (lbPosse13.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 24)
            {
                pbPlayer1.Location = label24.Location;
                if (lim[13] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[13] == 0 && lbPosse14.BackColor == Color.Violet)
                {
                    Program.money -= rent1[4];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[4];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[4] + " katittos";
                }
                if (lbPosse14.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 25)
            {
                pbPlayer1.Location = label25.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 26)
            {
                pbPlayer1.Location = label26.Location;
                if (lim[14] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[14] == 0 && lbPosse15.BackColor == Color.Violet)
                {
                    Program.money -= rent1[5];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[5];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[5] + " katittos";
                }
                if (lbPosse15.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 27)
            {
                pbPlayer1.Location = label27.Location;
                if (lim[15] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[15] == 0 && lbPosse16.BackColor == Color.Violet)
                {
                    Program.money -= rent1[5];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[5];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[5] + " katittos";
                }
                if (lbPosse16.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 28)
            {
                pbPlayer1.Location = label28.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 29)
            {
                pbPlayer1.Location = label29.Location;
                if (lim[16] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                 if (lim[16] == 0 && lbPosse17.BackColor == Color.Violet)
                {
                    Program.money -= rent1[5];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[5];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[5] + " katittos";
                }
                if (lbPosse17.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 30)
            {
                pbPlayer1.Location = label30.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 31)
            {
                pbPlayer1.Location = label31.Location;
                if (lim[17] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[17] == 0 && lbPosse18.BackColor == Color.Violet)
                {
                    Program.money -= rent1[6];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[6];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[6] + " katittos";
                }
                if (lbPosse18.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 32)
            {
                pbPlayer1.Location = label32.Location;
                if (lim[18] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[18] == 0 && lbPosse19.BackColor == Color.Violet)
                {
                    Program.money -= rent1[6];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[6];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[6] + " katittos";
                }
                if (lbPosse19.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 33)
            {
                pbPlayer1.Location = label33.Location;
                pbcomunidade.Visible = true;
                Random r = new Random();
                int com = r.Next(1, 6);
                if (com == 1)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade1;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                if (com == 2)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade2;
                    Program.money = Program.money - 50;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 50 katittos";
                }
                if (com == 3)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade3_1_;
                    back = 1;
                }
                if (com == 4)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade4;
                    Program.money = Program.money + 25;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 25 katittos";
                }
                if (com == 5)// MUDAR
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade5_1_;
                    Program.money = Program.money + 50;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 50 katittos";
                }
                disa = 2;
            }
            if (Program.pos == 34)
            {
                pbPlayer1.Location = label34.Location;
                if (lim[19] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[19] == 0 && lbPosse20.BackColor == Color.Violet)
                {
                    Program.money -= rent1[6];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[6];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[6] + " katittos";
                }
                if (lbPosse20.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 35)
            {
                pbPlayer1.Location = label35.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 36)
            {
                pbPlayer1.Location = label36.Location;
                panel1.Visible = false;
                panel2.Visible = true;
                pbsorte.Visible = true;
                Random r = new Random();
                int sorte = r.Next(1, 6);
                if (sorte == 1)//MUDAR
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte1_1_;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                if (sorte == 2)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte2;
                    Program.money = Program.money + 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 100 katittos";
                }
                if (sorte == 3)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte3_1_;
                    Program.money = Program.money + 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 100 katittos";
                }
                if (sorte == 4)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte4;
                    Program.money = Program.money + 150;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ganhou 150 katittos";
                }
                if (sorte == 5)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte5;
                    Program.money = Program.money - 100;
                    lbMoney.Text = Program.money.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem 100 katittos";
                }
                disa = 2;
            }
            if (Program.pos == 37)
            {
                pbPlayer1.Location = label37.Location;
                if (lim[20] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[20] == 0 && lbPosse21.BackColor == Color.Violet)
                {
                    Program.money -= rent1[7];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[7];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[7] + " katittos";
                }
                if (lbPosse21.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 38)
            {
                pbPlayer1.Location = label38.Location;
                panel1.Visible = false;
                panel2.Visible = true;
            }
            if (Program.pos == 39)
            {
                pbPlayer1.Location = label39.Location;
                if (lim[21] == 1 && volta >= 2)
                {
                    panel1.Visible = false;
                    compra.Visible = true; 
                }
                if (lim[21] == 0 && lbPosse22.BackColor == Color.Violet)
                {
                    Program.money -= rent1[7];
                    lbMoney.Text = Program.money.ToString();
                    Program.money2 += rent1[7];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    panel1.Visible = false;
                    panel2.Visible = true;
                    label47.Visible = true;
                    label47.Text = "O jogador 1 ficou sem " + rent1[7] + " katittos";
                }
                if (lbPosse22.BackColor == Color.Gold)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                }
            }
            if (Program.pos == 40)
            {
                pbPlayer1.Location = label40.Location;
                Program.money += 200;
                lbMoney.Text = Program.money.ToString();
                Program.pos = 0;
                panel1.Visible = false;
                panel2.Visible = true;
                volta++;
            }
            if (Program.pos == 41)
            {
                pbPlayer1.Location = label1.Location;
                Program.pos = 1;
                Program.money += 100;
                lbMoney.Text = Program.money.ToString();
                volta++;
                goto Inicio;
            }
            if (Program.pos == 42)
            {
                pbPlayer1.Location = label2.Location;
                Program.pos = 2;
                Program.money += 100;
                lbMoney.Text = Program.money.ToString();
                volta++;
                goto Inicio;
            }
            if (Program.pos == 43)
            {
                pbPlayer1.Location = label3.Location;
                Program.pos = 3;
                Program.money += 100;
                lbMoney.Text = Program.money.ToString();
                volta++;
                goto Inicio;
            }
            if (Program.pos == 44)
            {
                pbPlayer1.Location = label4.Location;
                Program.pos = 4;
                Program.money += 100;
                lbMoney.Text = Program.money.ToString();
                volta++;
                goto Inicio;
            }
            if (Program.pos == 45)
            {
                pbPlayer1.Location = label5.Location;
                Program.pos = 5;
                Program.money += 100;
                lbMoney.Text = Program.money.ToString();
                volta++;
                goto Inicio;
            }
            if (Program.pos == 46)
            {
                pbPlayer1.Location = label6.Location;
                Program.pos = 6;
                Program.money += 100;
                lbMoney.Text = Program.money.ToString();
                volta++;
                goto Inicio;
            }
            
            if(volta == 1 && back == 0) 
            {
                panel1.Visible = false;
                panel2.Visible = true;

            }

            if (disa1 == 2)
            {
                pbsorte.Visible = false;
                pbcomunidade.Visible = false;
                disa1 = 1;
            }
            

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnSim_Click(object sender, EventArgs e)
        {

            if (Program.pos == 1 && lim[0] == 1)
            {
                pbPlayer1.Location = label1.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[0];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 1;
                lim[0] = 0;
                lbPosse1.Visible = true;
                lbPosse1.BackColor = Color.Gold;
                Program.cor[0] = 1;
            } 
            if (Program.pos == 3 && lim[1] == 1)
            {
                pbPlayer1.Location = label3.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[0];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 2; 
                lim[1] = 0;
                lbPosse2.Visible = true;
                lbPosse2.BackColor = Color.Gold;
                Program.cor[0] = 1;
            }
            if (Program.pos == 6 && lim[2] == 1)
            {
                pbPlayer1.Location = label6.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[1];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 3;
                lim[2] = 0;
                lbPosse3.Visible = true;
                lbPosse3.BackColor = Color.Gold;
                Program.cor[1] = 2;
            }
            if (Program.pos == 8 && lim[3] == 1)
            {
                pbPlayer1.Location = label8.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[1];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 4;
                lim[3] = 0;
                lbPosse4.Visible = true;
                lbPosse4.BackColor = Color.Gold;
                Program.cor[1] = 2;
            }
            if (Program.pos == 9 && lim[4] == 1)
            {
                pbPlayer1.Location = label9.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[1];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 5;
                lim[4] = 0;
                lbPosse5.Visible = true;
                lbPosse5.BackColor = Color.Gold;
                Program.cor[1] = 2;
            }
            if (Program.pos == 11 && lim[5] == 1)
            {
                pbPlayer1.Location = label11.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[2];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 6;
                lim[5] = 0;
                lbPosse6.Visible = true;
                lbPosse6.BackColor = Color.Gold;
                Program.cor[2] = 3;
            }
            if (Program.pos == 13 && lim[6] == 1)
            {
                pbPlayer1.Location = label13.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[2];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 7;
                lim[6] = 0;
                lbPosse7.Visible = true;
                lbPosse7.BackColor = Color.Gold;
                Program.cor[2] = 3;
            }
            if (Program.pos == 14 && lim[7] == 1)
            {
                pbPlayer1.Location = label14.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[2];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 8;
                lim[7] = 0;
                lbPosse8.Visible = true;
                lbPosse8.BackColor = Color.Gold;
                Program.cor[2] = 3;
            }
            if (Program.pos == 16 && lim[8] == 1)
            {
                pbPlayer1.Location = label16.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[3];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 9;
                lim[8] = 0;
                lbPosse9.Visible = true;
                lbPosse9.BackColor = Color.Gold;
                Program.cor[3] = 4;
            }
            if (Program.pos == 18 && lim[9] == 1)
            {
                pbPlayer1.Location = label18.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[3];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 10;
                lim[9] = 0;
                lbPosse10.Visible = true;
                lbPosse10.BackColor = Color.Gold;
                Program.cor[3] = 4;
            }
            if (Program.pos == 19 && lim[10] == 1)
            {
                pbPlayer1.Location = label19.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[3];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 11;
                lim[10] = 0;
                lbPosse11.Visible = true;
                lbPosse11.BackColor = Color.Gold;
                Program.cor[3] = 4;
            }
            if (Program.pos == 21 && lim[11] == 1)
            {
                pbPlayer1.Location = label21.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[4];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 12;
                lim[11] = 0;
                lbPosse12.Visible = true;
                lbPosse12.BackColor = Color.Gold;
                Program.cor[4] = 5;
            }
            if (Program.pos == 23 && lim[12] == 1)
            {
                pbPlayer1.Location = label23.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[4];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 13;
                lim[12] = 0;
                lbPosse13.Visible = true;
                lbPosse13.BackColor = Color.Gold;
                Program.cor[4] = 5;
            }
            if (Program.pos == 24 && lim[13] == 1)
            {
                pbPlayer1.Location = label24.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[4];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 14;
                lim[13] = 0;
                lbPosse14.Visible = true;
                lbPosse14.BackColor = Color.Gold;
                Program.cor[4] = 5;
            }
            if (Program.pos == 26 && lim[14] == 1)
            {
                pbPlayer1.Location = label26.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[5];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 15;
                lim[14] = 0;
                lbPosse15.Visible = true;
                lbPosse15.BackColor = Color.Gold;
                Program.cor[5] = 6;
            }
            if (Program.pos == 27 && lim[15] == 1)
            {
                pbPlayer1.Location = label27.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[5];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 16;
                lim[15] = 0;
                lbPosse16.Visible = true;
                lbPosse16.BackColor = Color.Gold;
                Program.cor[5] = 6;
            }
            if (Program.pos == 29 && lim[16] == 1)
            {
                pbPlayer1.Location = label29.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[5];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 17;
                lim[16] = 0;
                lbPosse17.Visible = true;
                lbPosse17.BackColor = Color.Gold;
                Program.cor[5] = 6;
            }
            if (Program.pos == 31 && lim[17] == 1)
            {
                pbPlayer1.Location = label31.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[6];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 18;
                lim[17] = 0;
                lbPosse18.Visible = true;
                lbPosse18.BackColor = Color.Gold;
                Program.cor[6] = 7;
            }
            if (Program.pos == 32 && lim[18] == 1)
            {
                pbPlayer1.Location = label32.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[6];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 19;
                lim[18] = 0;
                lbPosse19.Visible = true;
                lbPosse19.BackColor = Color.Gold;
                Program.cor[6] = 7;
            }
            if (Program.pos == 34 && lim[19] == 1)
            {
                pbPlayer1.Location = label34.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[6];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 20;
                lim[19] = 0;
                lbPosse20.Visible = true;
                lbPosse20.BackColor = Color.Gold;
                Program.cor[6] = 7;
            }
            if (Program.pos == 37 && lim[20] == 1)
            {
                pbPlayer1.Location = label37.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[7];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 21;
                lim[20] = 0;
                lbPosse21.Visible = true;
                lbPosse21.BackColor = Color.Gold;
                Program.cor[7] = 8;
            }
            if (Program.pos == 39 && lim[21] == 1)
            {
                pbPlayer1.Location = label39.Location;
                compra.Visible = true;
                panel1.Visible = true;
                Program.money -= rent1[7];
                lbMoney.Text = Program.money.ToString();
                Program.compra = 22;
                lim[21] = 0;
                lbPosse22.Visible = true;
                lbPosse22.BackColor = Color.Gold;
                Program.cor[7] = 8;
            }
            if (Program.money <= -1)
            {
                Program.winloss = 1;
                Form form7 = new Form7();
                form7.Show();
                this.Hide();
            }
            panel1.Visible = false;
            panel2.Visible = true;
            compra.Visible = false;
        }

        private void btnNao_Click(object sender, EventArgs e)
        {
            compra.Visible = false;
            panel1.Visible = false;
            panel2.Visible = true;
        }

        private void cartas_Click(object sender, EventArgs e)
        {
            Form form4 = new Form4();
            form4.Show();
        }
        int volta2 = 1;

        private void btnGirarPlayer2_Click(object sender, EventArgs e)
        {
            int back = 0;
            Random random = new Random();
            int dado = random.Next(1, 7);

            //dado = 1;

            if (dado == 1)
            {
                pictureBox3.Image = MarketControl.Properties.Resources.dado1;
                Program.pos2 = Program.pos2 + 1;
            }
            if (dado == 2)
            {
                pictureBox3.Image = MarketControl.Properties.Resources.dado2;

                Program.pos2 = Program.pos2 + 2;
            }
            if (dado == 3)
            {
                pictureBox3.Image = MarketControl.Properties.Resources.dado3;
                Program.pos2 = Program.pos2 + 3;
            }
            if (dado == 4)
            {
                pictureBox3.Image = MarketControl.Properties.Resources.dado4;
                Program.pos2 = Program.pos2 + 4;
            }
            if (dado == 5)
            {
                pictureBox3.Image = MarketControl.Properties.Resources.dado5;
                Program.pos2 = Program.pos2 + 5;
            }
            if (dado == 6)
            {
                pictureBox3.Image = MarketControl.Properties.Resources.dado6;
                Program.pos2 = Program.pos2 += 6;
            }


        //----------------Posicao-----------------------------

        Inicio1:;
            if (Program.money2 <= -1)
            {
                Program.winloss = 2;
                Form form7 = new Form7();
                form7.Show();
                this.Hide();
            }
            if (Program.pos2 == 1)
            {
                pbPlayer2.Location = lbPos1Player2.Location;
                if (lim[0] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[0] == 0 && lbPosse1.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[0];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[0];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[0] + " katittos";
                }
                if (lbPosse1.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 2)
            {
                pbPlayer2.Location = lbPos2Player2.Location;
                pbcomunidade.Visible = true;
                Random r = new Random();
                int com = r.Next(1, 6);
                if (com == 1)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade1;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                if (com == 2)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade2;
                    Program.money2 = Program.money2 - 50;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 50 katittos";
                }
                if (com == 3)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade3_1_;
                    back = 1;
                }
                if (com == 4)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade4;
                    Program.money2 = Program.money2 + 25;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 25 katittos";
                }
                if (com == 5)// MUDAR
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade5_1_;
                    Program.money2 = Program.money2 + 50;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 50 katittos";
                }

                disa1 = 2;

            }
            if (Program.pos2 == 3)
            {
                pbPlayer2.Location = lbPos3Player2.Location;
                if (lim[1] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                 if (lim[1] == 0 && lbPosse2.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[0];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[0];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[0] + " katittos";
                }
                if (lbPosse2.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 4)
            {
                pbPlayer2.Location = lbPos4Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 5)
            {
                pbPlayer2.Location = lbPos5Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 6)
            {
                pbPlayer2.Location = lbPos6Player2.Location;
                if (lim[2] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                 if (lim[2] == 0 && lbPosse3.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[1];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[1];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[1] + " katittos";
                }
                if (lbPosse3.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 7)
            {
                pbPlayer2.Location = lbPos7Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
                pbsorte.Visible = true;
                Random r = new Random();
                int sorte = r.Next(1, 6);
                if (sorte == 1)//MUDAR
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte1_1_;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                if (sorte == 2)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte2;
                    Program.money2 = Program.money2 + 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 100 katittos";
                }
                if (sorte == 3)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte3_1_;
                    Program.money2 = Program.money2 + 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 100 katittos";
                }
                if (sorte == 4)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte4;
                    Program.money2 = Program.money2 + 150;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 150 katittos";
                }
                if (sorte == 5)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte5;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                disa1 = 2;
            }
            if (Program.pos2 == 8)
            {
                pbPlayer2.Location = lbPos8Player2.Location;
                if (lim[3] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                 if (lim[3] == 0 && lbPosse4.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[1];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[1];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[1] + " katittos";
                }
                if (lbPosse4.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 9)
            {
                pbPlayer2.Location = lbPos9Player2.Location;
                if (lim[4] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[4] == 0 && lbPosse5.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[1];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[1];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[1] + " katittos";
                }
                if (lbPosse5.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 10)
            {
                pbPlayer2.Location = lbPos10Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 11)
            {
                pbPlayer2.Location = lbPos11Player2.Location;
                if (lim[5] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[5] == 0 && lbPosse6.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[2];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[2];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[2] + " katittos";
                }
                if (lbPosse6.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 12)
            {
                pbPlayer2.Location = lbPos12Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 13)
            {
                pbPlayer2.Location = lbPos13Player2.Location;
                if (lim[6] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[6] == 0 && lbPosse7.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[2];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[2];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[2] + " katittos";
                }
                if (lbPosse7.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 14)
            {
                pbPlayer2.Location = lbPos14Player2.Location;
                if (lim[7] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true;  
                }
                if (lim[7] == 0 && lbPosse8.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[2];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[2];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[2] + " katittos";
                }
                if (lbPosse8.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 15)
            {
                pbPlayer2.Location = lbPos15Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 16)
            {
                pbPlayer2.Location = lbPos16Player2.Location;
                if (lim[8] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true;  
                }
                 if (lim[8] == 0 && lbPosse9.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[3];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[3];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[3] + " katittos";
                }
                if (lbPosse9.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 17)
            {
                pbPlayer2.Location = lbPos17Player2.Location;
                pbcomunidade.Visible = true;
                Random r = new Random();
                int com = r.Next(1, 6);
                if (com == 1)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade1;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                if (com == 2)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade2;
                    Program.money2 = Program.money2 - 50;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 50 katittos";
                }
                if (com == 3)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade3_1_;
                    back = 1;
                }
                if (com == 4)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade4;
                    Program.money2 = Program.money2 + 25;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 25 katittos";
                }
                if (com == 5)// MUDAR
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade5_1_;
                    Program.money2 = Program.money2 + 50;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 50 katittos";
                }
                disa1 = 2;
            }
            if (Program.pos2 == 18)
            {
                pbPlayer2.Location = lbPos18Player2.Location;
                if (lim[9] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                 if (lim[9] == 0 && lbPosse10.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[3];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[3];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[3] + " katittos";
                }
                if (lbPosse10.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 19)
            {
                pbPlayer2.Location = lbPos19Player2.Location;
                if (lim[10] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[10] == 0 && lbPosse11.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[3];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[3];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[3] + " katittos";
                }
                if (lbPosse11.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 20)
            {
                pbPlayer2.Location = lbPos20Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 21)
            {
                pbPlayer2.Location = lbPos21Player2.Location;
                if (lim[11] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[11] == 0 && lbPosse12.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[4];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[4];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[4] + " katittos";
                }
                if (lbPosse12.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 22)
            {
                pbPlayer2.Location = lbPos22Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
                pbsorte.Visible = true;
                Random r = new Random();
                int sorte = r.Next(1, 6);
                if (sorte == 1)//MUDAR
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte1_1_;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                if (sorte == 2)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte2;
                    Program.money2 = Program.money2 + 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 100 katittos";
                }
                if (sorte == 3)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte3_1_;
                    Program.money2 = Program.money2 + 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 100 katittos";
                }
                if (sorte == 4)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte4;
                    Program.money2 = Program.money2 + 150;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 150 katittos";
                }
                if (sorte == 5)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte5;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                disa1 = 2;
            }
            if (Program.pos2 == 23)
            {
                pbPlayer2.Location = lbPos23Player2.Location;
                if (lim[12] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[12] == 0 && lbPosse13.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[4];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[4];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[4] + " katittos";
                }
                if (lbPosse13.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 24)
            {
                pbPlayer2.Location = lbPos24Player2.Location;
                if (lim[13] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[13] == 0 && lbPosse14.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[4];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[4];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[4] + " katittos";
                }
                if (lbPosse14.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 25)
            {
                pbPlayer2.Location = lbPos25Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 26)
            {
                pbPlayer2.Location = lbPos26Player2.Location;
                if (lim[14] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true;  
                }
                 if (lim[14] == 0 && lbPosse15.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[5];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[5];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[5] + " katittos";
                }
                if (lbPosse15.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 27)
            {
                pbPlayer2.Location = lbPos27Player2.Location;
                if (lim[15] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true;  
                }
                 if (lim[15] == 0 && lbPosse16.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[5];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[5];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[5] + " katittos";
                }
                if (lbPosse16.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 28)
            {
                pbPlayer2.Location = lbPos28Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 29)
            {
                pbPlayer2.Location = lbPos29Player2.Location;
                if (lim[16] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[16] == 0 && lbPosse17.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[5];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[5];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[5] + " katittos";
                }
                if (lbPosse17.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 30)
            {
                pbPlayer2.Location = lbPos30Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 31)
            {
                pbPlayer2.Location = lbPos31Player2.Location;
                if (lim[17] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                 if (lim[17] == 0 && lbPosse18.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[6];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[6];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[6] + " katittos";
                }
                if (lbPosse18.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 32)
            {
                pbPlayer2.Location = lbPos32Player2.Location;
                if (lim[18] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[18] == 0 && lbPosse19.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[6];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[6];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[6] + " katittos";
                }
                if (lbPosse19.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 33)
            {
                pbPlayer2.Location = lbPos33Player2.Location;
                pbcomunidade.Visible = true;
                Random r = new Random();
                int com = r.Next(1, 6);
                if (com == 1)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade1;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                if (com == 2)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade2;
                    Program.money2 = Program.money2 - 50;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 50 katittos";
                }
                if (com == 3)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade3_1_;
                    back = 1;
                }
                if (com == 4)
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade4;
                    Program.money2 = Program.money2 + 25;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 25 katittos";
                }
                if (com == 5)// MUDAR
                {
                    pbcomunidade.Image = MarketControl.Properties.Resources.comunidade5_1_;
                    Program.money2 = Program.money2 + 50;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 50 katittos";
                }
                disa1 = 2;
            }
            if (Program.pos2 == 34)
            {
                pbPlayer2.Location = lbPos34Player2.Location;
                if (lim[19] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[19] == 0 && lbPosse20.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[6];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[6];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[6] + " katittos";
                }
                if (lbPosse20.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 35)
            {
                pbPlayer2.Location = lbPos35Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 36)
            {
                pbPlayer2.Location = lbPos36Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
                pbsorte.Visible = true;
                Random r = new Random();
                int sorte = r.Next(1, 6);
                if (sorte == 1)//MUDAR
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte1_1_;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                if (sorte == 2)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte2;
                    Program.money2 = Program.money2 + 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 100 katittos";
                }
                if (sorte == 3)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte3_1_;
                    Program.money2 = Program.money2 + 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 100 katittos";
                }
                if (sorte == 4)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte4;
                    Program.money2 = Program.money2 + 150;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ganhou 150 katittos";
                }
                if (sorte == 5)
                {
                    pbsorte.Image = MarketControl.Properties.Resources.sorte5;
                    Program.money2 = Program.money2 - 100;
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem 100 katittos";
                }
                disa1 = 2;
            }
            if (Program.pos2 == 37)
            {
                pbPlayer2.Location = lbPos37Player2.Location;
                if (lim[20] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                if (lim[20] == 0 && lbPosse21.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[7];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[7];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[7] + " katittos";
                }
                if (lbPosse21.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 38)
            {
                pbPlayer2.Location = lbPos38Player2.Location;
                panel1.Visible = true;
                panel2.Visible = false;
            }
            if (Program.pos2 == 39)
            {
                pbPlayer2.Location = lbPos39Player2.Location;
                if (lim[21] == 1 && volta2 >= 2)
                {
                    panel2.Visible = false;
                    compra2.Visible = true; 
                }
                 if (lim[21] == 0 && lbPosse22.BackColor == Color.Gold)
                {
                    Program.money2 -= rent1[7];
                    lbMoneyPlayer2.Text = Program.money2.ToString();
                    Program.money += rent1[7];
                    lbMoney.Text = Program.money.ToString();
                    panel1.Visible = true;
                    panel2.Visible = false;
                    label47.Visible = true;
                    label47.Text = "O jogador 2 ficou sem " + rent1[7] + " katittos";
                }
                if (lbPosse22.BackColor == Color.Violet)
                {
                    panel1.Visible = true;
                    panel2.Visible = false;
                }
            }
            if (Program.pos2 == 40)
            {
                pbPlayer2.Location = lbPos40Player2.Location;
                Program.money2 += 200;
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.pos2 = 0;
                volta2++;
                panel1.Visible = true;
                panel2.Visible = false;

            }
            if (Program.pos2 == 41)
            {
                pbPlayer2.Location = lbPos1Player2.Location;
                Program.pos2 = 1;
                Program.money2 += 100;
                lbMoneyPlayer2.Text = Program.money2.ToString();
                volta2++;
                goto Inicio1;
            }
            if (Program.pos2 == 42)
            {
                pbPlayer2.Location = lbPos2Player2.Location;
                Program.pos2 = 2;
                Program.money2 += 100;
                lbMoneyPlayer2.Text = Program.money2.ToString();
                volta2++;
                goto Inicio1;
            }
            if (Program.pos2 == 43)
            {
                pbPlayer2.Location = lbPos3Player2.Location;
                Program.pos2 = 3;
                Program.money2 += 100;
                lbMoneyPlayer2.Text = Program.money2.ToString();
                volta2++;
                goto Inicio1;
            }
            if (Program.pos2 == 44)
            {
                pbPlayer2.Location = lbPos4Player2.Location;
                Program.pos2 = 4;
                Program.money2 += 100;
                lbMoneyPlayer2.Text = Program.money2.ToString();
                volta2++;
                goto Inicio1;
            }
            if (Program.pos2 == 45)
            {
                pbPlayer2.Location = lbPos5Player2.Location;
                Program.pos2 = 5;
                Program.money2 += 100;
                lbMoneyPlayer2.Text = Program.money2.ToString();
                volta2++;
                goto Inicio1;
            }
            if (Program.pos2 == 46)
            {
                pbPlayer2.Location = lbPos6Player2.Location;
                Program.pos2 = 6;
                Program.money2 += 100;
                lbMoneyPlayer2.Text = Program.money2.ToString();
                volta2++;
                goto Inicio1;
            }

            if(volta2 == 1 && back == 0) 
            { 
                panel1.Visible = true;
                panel2.Visible = false;
            }

            if (disa == 2)
            {
                pbsorte.Visible = false;
                pbcomunidade.Visible = false;
                disa = 1; 
            }
            
        }

        private void btnSim2_Click(object sender, EventArgs e)
        {
            if (Program.pos2 == 1 && lim[0] == 1)
            {
                pbPlayer2.Location = lbPos1Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[0];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 1;
                lim[0] = 0;
                lbPosse1.Visible = true;
                lbPosse1.BackColor = Color.Violet;
                Program.cor1[0] = 1;
            }
            if (Program.pos2 == 3 && lim[1] == 1)
            {
                pbPlayer2.Location = lbPos3Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[0];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 2;
                lim[1] = 0;
                lbPosse2.Visible = true;
                lbPosse2.BackColor = Color.Violet;
                Program.cor1[0] = 1;
            }
            if (Program.pos2 == 6 && lim[2] == 1)
            {
                pbPlayer2.Location = lbPos6Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[1];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 3;
                lim[2] = 0;
                lbPosse3.Visible = true;
                lbPosse3.BackColor = Color.Violet;
                Program.cor1[1] = 2;
            }
            if (Program.pos2 == 8 && lim[3] == 1)
            {
                pbPlayer2.Location = lbPos8Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[1];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 4;
                lim[3] = 0;
                lbPosse4.Visible = true;
                lbPosse4.BackColor = Color.Violet;
                Program.cor1[1] = 2;
            }
            if (Program.pos2 == 9 && lim[4] == 1)
            {
                pbPlayer2.Location = lbPos9Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[1];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 5;
                lim[4] = 0;
                lbPosse5.Visible = true;
                lbPosse5.BackColor = Color.Violet;
                Program.cor1[1] = 2;
            }
            if (Program.pos2 == 11 && lim[5] == 1)
            {
                pbPlayer2.Location = lbPos11Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[2];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 6;
                lim[5] = 0;
                lbPosse6.Visible = true;
                lbPosse6.BackColor = Color.Violet;
                Program.cor1[2] = 3;
            }
            if (Program.pos2 == 13 && lim[6] == 1)
            {
                pbPlayer2.Location = lbPos13Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[2];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 7;
                lim[6] = 0;
                lbPosse7.Visible = true;
                lbPosse7.BackColor = Color.Violet;
                Program.cor1[2] = 3;
            }
            if (Program.pos2 == 14 && lim[7] == 1)
            {
                pbPlayer2.Location = lbPos14Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[2];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 8;
                lim[7] = 0;
                lbPosse8.Visible = true;
                lbPosse8.BackColor = Color.Violet;
                Program.cor1[2] = 3;
            }
            if (Program.pos2 == 16 && lim[8] == 1)
            {
                pbPlayer2.Location = lbPos16Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[3];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 9;
                lim[8] = 0;
                lbPosse9.Visible = true;
                lbPosse9.BackColor = Color.Violet;
                Program.cor1[3] = 4;
            }
            if (Program.pos2 == 18 && lim[9] == 1)
            {
                pbPlayer2.Location = lbPos18Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[3];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 10;
                lim[9] = 0;
                lbPosse10.Visible = true;
                lbPosse10.BackColor = Color.Violet;
                Program.cor1[3] = 4;
            }
            if (Program.pos2 == 19 && lim[10] == 1)
            {
                pbPlayer2.Location = lbPos19Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[3];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 11;
                lim[10] = 0;
                lbPosse11.Visible = true;
                lbPosse11.BackColor = Color.Violet;
                Program.cor1[3] = 4;
            }
            if (Program.pos2 == 21 && lim[11] == 1)
            {
                pbPlayer2.Location = lbPos21Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[4];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 12;
                lim[11] = 0;
                lbPosse12.Visible = true;
                lbPosse12.BackColor = Color.Violet;
                Program.cor1[4] = 5;
            }
            if (Program.pos2 == 23 && lim[12] == 1)
            {
                pbPlayer2.Location = lbPos23Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[4];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 13;
                lim[12] = 0;
                lbPosse13.Visible = true;
                lbPosse13.BackColor = Color.Violet;
                Program.cor1[4] = 5;
            }
            if (Program.pos2 == 24 && lim[13] == 1)
            {
                pbPlayer2.Location = lbPos24Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[4];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 14;
                lim[13] = 0;
                lbPosse14.Visible = true;
                lbPosse14.BackColor = Color.Violet;
                Program.cor1[4] = 5;
            }
            if (Program.pos2 == 26 && lim[14] == 1)
            {
                pbPlayer2.Location = lbPos26Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[5];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 15;
                lim[14] = 0;
                lbPosse15.Visible = true;
                lbPosse15.BackColor = Color.Violet;
                Program.cor1[5] = 6;
            }
            if (Program.pos2 == 27 && lim[15] == 1)
            {
                pbPlayer2.Location = lbPos27Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[5];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 16;
                lim[15] = 0;
                lbPosse16.Visible = true;
                lbPosse16.BackColor = Color.Violet;
                Program.cor1[5] = 6;
            }
            if (Program.pos2 == 29 && lim[16] == 1)
            {
                pbPlayer2.Location = lbPos29Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[5];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 17;
                lim[16] = 0;
                lbPosse17.Visible = true;
                lbPosse17.BackColor = Color.Violet;
                Program.cor1[5] = 6;
            }
            if (Program.pos2 == 31 && lim[17] == 1)
            {
                pbPlayer2.Location = lbPos31Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[6];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 18;
                lim[17] = 0;
                lbPosse18.Visible = true;
                lbPosse18.BackColor = Color.Violet;
                Program.cor1[6] = 7;
            }
            if (Program.pos2 == 32 && lim[18] == 1)
            {
                pbPlayer2.Location = lbPos32Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[6];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 19;
                lim[18] = 0;
                lbPosse19.Visible = true;
                lbPosse19.BackColor = Color.Violet;
                Program.cor1[6] = 7;
            }
            if (Program.pos2 == 34 && lim[19] == 1)
            {
                pbPlayer2.Location = lbPos34Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[6];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 20;
                lim[19] = 0;
                lbPosse20.Visible = true;
                lbPosse20.BackColor = Color.Violet;
                Program.cor1[6] = 7;
            }
            if (Program.pos2 == 37 && lim[20] == 1)
            {
                pbPlayer2.Location = lbPos37Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[7];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 21;
                lim[20] = 0;
                lbPosse21.Visible = true;
                lbPosse21.BackColor = Color.Violet;
                Program.cor1[7] = 8;
            }
            if (Program.pos2 == 39 && lim[21] == 1)
            {
                pbPlayer2.Location = lbPos39Player2.Location;
                compra2.Visible = true;
                panel2.Visible = true;
                Program.money2 -= rent1[7];
                lbMoneyPlayer2.Text = Program.money2.ToString();
                Program.compra1 = 22;
                lim[21] = 0;
                lbPosse22.Visible = true;
                lbPosse22.BackColor = Color.Violet;
                Program.cor1[7] = 8;
            }
            if (Program.money2 <= -1)
            {
                Program.winloss = 2;
                Form form7 = new Form7();
                form7.Show();
                this.Hide();
            }
            compra2.Visible = false;
            panel1.Visible = true;
            panel2.Visible = false;

            
        }

        private void btnNao2_Click(object sender, EventArgs e)
        {
            compra2.Visible = false;
            panel1.Visible = true;
            panel2.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form form5 = new Form5();
            form5.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form form2 = new Form2();
            form2.Show();
            this.Hide();
        }
    }
}
